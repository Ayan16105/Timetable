package dao;

import model.Room;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomDAO {
    public List<Room> getAllRooms() throws SQLException {
        List<Room> rooms = new ArrayList<>();
        String query = "SELECT * FROM Room";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                rooms.add(new Room(
                    rs.getInt("RoomId"),
                    rs.getString("Name"),
                    rs.getString("BuildingName"),
                    rs.getBoolean("IsLab"),
                    rs.getInt("Capacity")
                ));
            }
        }
        return rooms;
    }

    public void addRoom(Room room) throws SQLException {
        String query = "INSERT INTO Room (Name, BuildingName, IsLab, Capacity) VALUES (?, ?, ?, ?)";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, room.getName());
            stmt.setString(2, room.getBuildingName());
            stmt.setBoolean(3, room.isLab());
            stmt.setInt(4, room.getCapacity());
            stmt.executeUpdate();
        }
    }

    public void updateRoom(Room room) throws SQLException {
        String query = "UPDATE Room SET Name = ?, BuildingName = ?, IsLab = ?, Capacity = ? WHERE RoomId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, room.getName());
            stmt.setString(2, room.getBuildingName());
            stmt.setBoolean(3, room.isLab());
            stmt.setInt(4, room.getCapacity());
            stmt.setInt(5, room.getRoomId());
            stmt.executeUpdate();
        }
    }

    public void deleteRoom(int roomId) throws SQLException {
        String query = "DELETE FROM Room WHERE RoomId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, roomId);
            stmt.executeUpdate();
        }
    }

    public Room getRoomById(int roomId) throws SQLException {
        String query = "SELECT * FROM Room WHERE RoomId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, roomId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Room(
                        rs.getInt("RoomId"),
                        rs.getString("Name"),
                        rs.getString("BuildingName"),
                        rs.getBoolean("IsLab"),
                        rs.getInt("Capacity")
                    );
                }
            }
        }
        return null;
    }
}