package dao;

import model.Teacher;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAO {

    public void addTeacher(Teacher teacher) throws SQLException {
        String query = "INSERT INTO Teacher (Name) VALUES (?)";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, teacher.getName());
            stmt.executeUpdate();
        }
    }

    public void updateTeacher(Teacher teacher) throws SQLException {
        String query = "UPDATE Teacher SET Name = ? WHERE TeacherId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, teacher.getName());
            stmt.setInt(2, teacher.getTeacherId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Teacher with ID " + teacher.getTeacherId() + " not found.");
            }
        }
    }

    public void deleteTeacher(int teacherId) throws SQLException {
        String query = "DELETE FROM Teacher WHERE TeacherId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, teacherId);
            stmt.executeUpdate();
        }
    }

    public List<Teacher> getAllTeachers() throws SQLException {
        List<Teacher> teachers = new ArrayList<>();
        String query = "SELECT * FROM Teacher";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                teachers.add(new Teacher(
                    rs.getInt("TeacherId"),
                    rs.getString("Name")
                ));
            }
        }
        return teachers;
    }

    public Teacher getTeacherById(int teacherId) throws SQLException {
        String query = "SELECT * FROM Teacher WHERE TeacherId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, teacherId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Teacher(
                        rs.getInt("TeacherId"),
                        rs.getString("Name")
                    );
                }
            }
        }
        return null;
    }

    public Teacher getTeacherByName(String name) throws SQLException {
        String query = "SELECT * FROM Teacher WHERE Name = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Teacher(
                        rs.getInt("TeacherId"),
                        rs.getString("Name")
                    );
                }
            }
        }
        return null;
    }
}