package dao;

import model.Subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.DBConnection;

public class SubjectDAO {
    public List<Subject> getSubjectsByBatchId(int batchId) throws SQLException {
        List<Subject> subjects = new ArrayList<>();
        String query = "SELECT * FROM Subject WHERE BatchId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, batchId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    subjects.add(new Subject(
                        rs.getInt("SubjectId"),
                        rs.getInt("BatchId"),
                        rs.getInt("TeacherId"),
                        rs.getString("Name"),
                        rs.getBoolean("IsLab")
                    ));
                }
            }
        }
        return subjects;
    }

    

    public void addSubject(Subject subject) throws SQLException {
        String query = "INSERT INTO Subject (BatchId, TeacherId, Name, IsLab) VALUES (?, ?, ?, ?)";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, subject.getBatchId());
            stmt.setInt(2, subject.getTeacherId());
            stmt.setString(3, subject.getName());
            stmt.setBoolean(4, subject.isLab());
            stmt.executeUpdate();
        }
    }

    public void updateSubject(Subject subject) throws SQLException {
        String query = "UPDATE Subject SET BatchId = ?, TeacherId = ?, Name = ?, IsLab = ? WHERE SubjectId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, subject.getBatchId());
            stmt.setInt(2, subject.getTeacherId());
            stmt.setString(3, subject.getName());
            stmt.setBoolean(4, subject.isLab());
            stmt.setInt(5, subject.getSubjectId());
            stmt.executeUpdate();
        }
    }

    public void deleteSubject(int subjectId) throws SQLException {
        // First delete timetable entries related to this subject
        String deleteTimetableQuery = "DELETE FROM timetable WHERE SubjectId = ?";
        
        // Then delete the subject itself
        String deleteSubjectQuery = "DELETE FROM subject WHERE SubjectId = ?";
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Start transaction
            
            // Delete timetable entries first
            try (PreparedStatement stmt = conn.prepareStatement(deleteTimetableQuery)) {
                stmt.setInt(1, subjectId);
                stmt.executeUpdate();
            }
            
            // Now delete the subject
            try (PreparedStatement stmt = conn.prepareStatement(deleteSubjectQuery)) {
                stmt.setInt(1, subjectId);
                stmt.executeUpdate();
            }
            
            conn.commit(); // Commit transaction
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback in case of error
                } catch (SQLException ex) {
                    throw new SQLException("Error during rollback: " + ex.getMessage());
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true); // Reset auto-commit
                conn.close();
            }
        }
    }
    public List<Subject> getAllSubjects() throws SQLException {
    List<Subject> subjects = new ArrayList<>();
    String query = "SELECT * FROM Subject";
    
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        
        while (rs.next()) {
            Subject subject = new Subject(
                rs.getInt("SubjectId"),
                rs.getInt("BatchId"),
                rs.getInt("TeacherId"),
                rs.getString("Name"),
                rs.getBoolean("IsLab")
            );
            subjects.add(subject);
        }
    }
    
    return subjects;
}
    public int getTeacherIdForSubject(int subjectId) throws SQLException {
        String query = "SELECT TeacherId FROM Subject WHERE SubjectId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, subjectId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("TeacherId");
                }
            }
        }
        return -1; // Return -1 if teacher not found
    }
}
