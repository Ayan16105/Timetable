package dao;

import model.Batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import db.DBConnection;

public class BatchDAO {
    public List<Batch> getAllBatches() throws SQLException {
        List<Batch> batches = new ArrayList<>();
        String query = "SELECT * FROM Batch";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                batches.add(new Batch(
                    rs.getInt("BatchId"),
                    rs.getString("Name"),
                    rs.getInt("NoOfStudents"),
                    rs.getTime("StartTime").toLocalTime(),
                    rs.getTime("EndTime").toLocalTime(),
                    rs.getTime("BreakTime").toLocalTime(),
                    rs.getString("BuildingName")
                ));
            }
        }
        return batches;
    }

    public void addBatch(Batch batch) throws SQLException {
        String query = "INSERT INTO Batch (Name, NoOfStudents, StartTime, EndTime, BreakTime, BuildingName) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, batch.getName());
            stmt.setInt(2, batch.getNoOfStudents());
            stmt.setTime(3, java.sql.Time.valueOf(batch.getStartTime()));
            stmt.setTime(4, java.sql.Time.valueOf(batch.getEndTime()));
            stmt.setTime(5, java.sql.Time.valueOf(batch.getBreakTime()));
            stmt.setString(6, batch.getBuildingName());
            stmt.executeUpdate();
        }
    }

    public void updateBatch(Batch batch) throws SQLException {
        String query = "UPDATE Batch SET Name = ?, NoOfStudents = ?, StartTime = ?, EndTime = ?, BreakTime = ?, BuildingName = ? WHERE BatchId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, batch.getName());
            stmt.setInt(2, batch.getNoOfStudents());
            stmt.setTime(3, java.sql.Time.valueOf(batch.getStartTime()));
            stmt.setTime(4, java.sql.Time.valueOf(batch.getEndTime()));
            stmt.setTime(5, java.sql.Time.valueOf(batch.getBreakTime()));
            stmt.setString(6, batch.getBuildingName());
            stmt.setInt(7, batch.getBatchId());
            stmt.executeUpdate();
        }
    }

    public void deleteBatch(int batchId) throws SQLException {
    // First delete timetable entries related to this batch's subjects
    String deleteTimetableQuery = "DELETE FROM timetable WHERE SubjectId IN (SELECT SubjectId FROM subject WHERE BatchId = ?)";
    
    // Then delete subjects related to this batch
    String deleteSubjectsQuery = "DELETE FROM subject WHERE BatchId = ?";
    
    // Finally delete the batch itself
    String deleteBatchQuery = "DELETE FROM batch WHERE BatchId = ?";
    
    Connection conn = null;
    try {
        conn = DBConnection.getConnection();
        conn.setAutoCommit(false); // Start transaction
        
        // Delete timetable entries first
        try (PreparedStatement stmt = conn.prepareStatement(deleteTimetableQuery)) {
            stmt.setInt(1, batchId);
            stmt.executeUpdate();
        }
        
        // Delete subjects next
        try (PreparedStatement stmt = conn.prepareStatement(deleteSubjectsQuery)) {
            stmt.setInt(1, batchId);
            stmt.executeUpdate();
        }
        
        // Finally delete the batch itself
        try (PreparedStatement stmt = conn.prepareStatement(deleteBatchQuery)) {
            stmt.setInt(1, batchId);
            stmt.executeUpdate();
        }
        
        conn.commit(); // Commit transaction
    } catch (SQLException e) {
        if (conn != null) {
            try {
                conn.rollback(); // Rollback in case of error
            } catch (SQLException ex) {
                throw new SQLException("Error during rollback: " + ex.getMessage());
            }
        }
        throw e;
    } finally {
        if (conn != null) {
            conn.setAutoCommit(true); // Reset auto-commit
            conn.close();
        }
    }
}

    public Batch getBatchByName(String name) throws SQLException {
        String query = "SELECT * FROM Batch WHERE Name = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Batch(
                        rs.getInt("BatchId"),
                        rs.getString("Name"),
                        rs.getInt("NoOfStudents"),
                        rs.getTime("StartTime").toLocalTime(),
                        rs.getTime("EndTime").toLocalTime(),
                        rs.getTime("BreakTime").toLocalTime(),
                        rs.getString("BuildingName")
                    );
                }
            }
        }
        return null;
    }
}