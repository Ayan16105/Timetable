package dao;

import model.TimeSlot;
import java.sql.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TimeSlotDAO {
    private static final DateTimeFormatter DISPLAY_FORMATTER = DateTimeFormatter.ofPattern("hh:mm a"); // 12-hour format for display
    private static final DateTimeFormatter DB_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss"); // 24-hour format for database

    public void clearTimeSlots() throws SQLException {
        String query = "DELETE FROM timeSlot";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.executeUpdate();
        }
    }

    public void clearTimeSlotsForBatch(int batchId) throws SQLException {
        String sql = "DELETE FROM TimeSlot WHERE BatchId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, batchId);
            stmt.executeUpdate();
        }
    }

    public void addTimeSlot(TimeSlot timeSlot) throws SQLException {
        String query = "INSERT INTO timeSlot (StartTime, EndTime, IsBreak, BatchId) VALUES (?, ?, ?, ?)";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            // Convert 12-hour format to 24-hour for database storage
            stmt.setString(1, timeSlot.getStartTime().format(DB_FORMATTER));
            stmt.setString(2, timeSlot.getEndTime().format(DB_FORMATTER));
            stmt.setBoolean(3, timeSlot.isBreak());
            stmt.setInt(4, timeSlot.getBatchId());
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    timeSlot.setTimeSlotId(rs.getInt(1));
                }
            }
        }
    }

    public TimeSlot getTimeSlotById(int timeSlotId) throws SQLException {
        String query = "SELECT * FROM timeSlot WHERE TimeSlotId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, timeSlotId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Parse 24-hour format from database and return as LocalTime
                    LocalTime startTime = LocalTime.parse(rs.getString("StartTime"), DB_FORMATTER);
                    LocalTime endTime = LocalTime.parse(rs.getString("EndTime"), DB_FORMATTER);
                    return new TimeSlot(
                        rs.getInt("TimeSlotId"),
                        startTime,
                        endTime,
                        rs.getBoolean("IsBreak"),
                        rs.getInt("BatchId")
                    );
                }
            }
        }
        return null;
    }

    public List<TimeSlot> getAllTimeSlots() throws SQLException {
        List<TimeSlot> timeSlots = new ArrayList<>();
        String query = "SELECT * FROM timeSlot ORDER BY StartTime";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                LocalTime startTime = LocalTime.parse(rs.getString("StartTime"), DB_FORMATTER);
                LocalTime endTime = LocalTime.parse(rs.getString("EndTime"), DB_FORMATTER);
                timeSlots.add(new TimeSlot(
                    rs.getInt("TimeSlotId"),
                    startTime,
                    endTime,
                    rs.getBoolean("IsBreak"),
                    rs.getInt("BatchId")
                ));
            }
        }
        return timeSlots;
    }
}