package dao;

import model.Timetable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TimetableDAO {

    public void clearTimetable() throws SQLException {
        String query = "DELETE FROM Timetable";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.executeUpdate();
        }
    }

    public boolean isBatchScheduled(int batchId, int timeSlotId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Timetable WHERE BatchId = ? AND TimeSlotId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, batchId);
            stmt.setInt(2, timeSlotId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public boolean isRoomScheduled(int roomId, int timeSlotId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Timetable WHERE RoomId = ? AND TimeSlotId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, roomId);
            stmt.setInt(2, timeSlotId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public boolean isTeacherScheduled(int teacherId, int timeSlotId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Timetable t " +
                      "JOIN Subject s ON t.SubjectId = s.SubjectId " +
                      "WHERE s.TeacherId = ? AND t.TimeSlotId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, teacherId);
            stmt.setInt(2, timeSlotId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public int getTotalStudentsInRoom(int roomId, int timeSlotId) throws SQLException {
        String query = "SELECT SUM(b.NoOfStudents) as total FROM Timetable t " +
                      "JOIN Batch b ON t.BatchId = b.BatchId " +
                      "WHERE t.RoomId = ? AND t.TimeSlotId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, roomId);
            stmt.setInt(2, timeSlotId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
        }
        return 0;
    }

    public void addTimetable(Timetable timetable) throws SQLException {
        String query = "INSERT INTO Timetable (BatchId, SubjectId, RoomId, TimeSlotId) VALUES (?, ?, ?, ?)";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, timetable.getBatchId());
            stmt.setInt(2, timetable.getSubjectId());
            stmt.setInt(3, timetable.getRoomId());
            stmt.setInt(4, timetable.getTimeSlotId());
            stmt.executeUpdate();
        }
    }
    public List<Timetable> getTimetableByTeacher(int teacherId) throws SQLException {
        List<Timetable> timetables = new ArrayList<>();
        String query = "SELECT t.* FROM Timetable t JOIN Subject s ON t.SubjectId = s.SubjectId WHERE s.TeacherId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, teacherId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    timetables.add(new Timetable(
                        rs.getInt("TimetableId"),
                        rs.getInt("BatchId"),
                        rs.getInt("SubjectId"),
                        rs.getInt("RoomId"),
                        rs.getInt("TimeSlotId")
                    ));
                }
            }
        }
        return timetables;
    }

    public void clearTimetableForBatch(int batchId) throws SQLException {
        String sql = "DELETE FROM Timetable WHERE BatchId = ?";
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, batchId);
            stmt.executeUpdate();
        }
    }

    public List<Timetable> getTimetableByBatch(String batchName) throws SQLException {
        if (batchName == null || batchName.trim().isEmpty()) {
            throw new IllegalArgumentException("Batch name cannot be null or empty");
        }

        List<Timetable> timetable = new ArrayList<>();
        String query = "SELECT t.* FROM Timetable t JOIN Batch b ON t.BatchId = b.BatchId WHERE b.Name = ?";
        
        try (Connection conn = db.DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, batchName);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Timetable entry = new Timetable(
                        rs.getInt("TimetableId"),
                        rs.getInt("BatchId"),
                        rs.getInt("SubjectId"),
                        rs.getInt("RoomId"),
                        rs.getInt("TimeSlotId")
                    );
                    timetable.add(entry);
                }
            }
        }
        return timetable;
    }
}