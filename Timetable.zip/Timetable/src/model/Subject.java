package model;

public class Subject {
    private int subjectId;
    private int batchId;
    private int teacherId;
    private String name;
    private boolean isLab;

    public Subject(int subjectId, int batchId, int teacherId, String name, boolean isLab) {
        this.subjectId = subjectId;
        this.batchId = batchId;
        this.teacherId = teacherId;
        this.name = name;
        this.isLab = isLab;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isLab() {
        return isLab;
    }

    public void setLab(boolean lab) {
        this.isLab = lab;
    }
}