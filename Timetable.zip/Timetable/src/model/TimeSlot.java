package model;

import java.time.LocalTime;

public class TimeSlot {
    private int timeSlotId;
    private LocalTime startTime;
    private LocalTime endTime;
    private boolean isBreak;
    private int batchId; // Add this field

    public TimeSlot(int timeSlotId, LocalTime startTime, LocalTime endTime, boolean isBreak, int batchId) {
        this.timeSlotId = timeSlotId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isBreak = isBreak;
        this.batchId = batchId;
    }

    // Getters and setters
    public int getTimeSlotId() { return timeSlotId; }
    public void setTimeSlotId(int timeSlotId) { this.timeSlotId = timeSlotId; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public boolean isBreak() { return isBreak; }
    public int getBatchId() { return batchId; }
    public void setBatchId(int batchId) { this.batchId = batchId; }
}