package model;

public class Room {
    private int roomId;
    private String name;
    private String buildingName;
    private boolean isLab;
    private int capacity;

    public Room(int roomId, String name, String buildingName, boolean isLab, int capacity) {
        this.roomId = roomId;
        this.name = name;
        this.buildingName = buildingName;
        this.isLab = isLab;
        this.capacity = capacity;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public boolean isLab() {
        return isLab;
    }

    public void setLab(boolean lab) {
        this.isLab = lab;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
}