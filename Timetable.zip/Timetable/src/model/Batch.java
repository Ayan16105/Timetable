package model;

import java.time.LocalTime;

public class Batch {
    private int batchId;
    private String name;
    private int noOfStudents;
    private LocalTime startTime;
    private LocalTime endTime;
    private LocalTime breakTime;
    private String buildingName;

    public Batch(int batchId, String name, int noOfStudents, LocalTime startTime, LocalTime endTime, LocalTime breakTime, String buildingName) {
        this.batchId = batchId;
        this.name = name;
        this.noOfStudents = noOfStudents;
        this.startTime = startTime;
        this.endTime = endTime;
        this.breakTime = breakTime;
        this.buildingName = buildingName;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNoOfStudents() {
        return noOfStudents;
    }

    public void setNoOfStudents(int noOfStudents) {
        this.noOfStudents = noOfStudents;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public LocalTime getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(LocalTime breakTime) {
        this.breakTime = breakTime;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }
}