package model;

public class Timetable {
    private int timetableId;
    private int batchId;
    private int subjectId;
    private int roomId;
    private int timeSlotId;

    public Timetable(int timetableId, int batchId, int subjectId, int roomId, int timeSlotId) {
        this.timetableId = timetableId;
        this.batchId = batchId;
        this.subjectId = subjectId;
        this.roomId = roomId;
        this.timeSlotId = timeSlotId;
    }

    public int getTimetableId() {
        return timetableId;
    }

    public void setTimetableId(int timetableId) {
        this.timetableId = timetableId;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public int getTimeSlotId() {
        return timeSlotId;
    }

    public void setTimeSlotId(int timeSlotId) {
        this.timeSlotId = timeSlotId;
    }
}