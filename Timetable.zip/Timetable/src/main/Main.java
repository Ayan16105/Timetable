package main;



import javax.swing.*;

import gui.TimetableGUI;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TimetableGUI gui = new TimetableGUI();
            gui.setVisible(true);
        });
    }
}