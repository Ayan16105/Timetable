import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class TestSwing {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Swing Test");
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            DefaultTableModel model = new DefaultTableModel(new String[]{"Column1", "Column2"}, 0);
            JTable table = new JTable(model);
            model.addRow(new Object[]{"Test", "Data"});

            frame.add(new JScrollPane(table));
            frame.setVisible(true);
        });
    }
}