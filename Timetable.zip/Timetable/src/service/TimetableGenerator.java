package service;

import dao.*;
import model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TimetableGenerator {
    private final RoomDAO roomDAO = new RoomDAO();
    private final BatchDAO batchDAO = new BatchDAO();
    private final SubjectDAO subjectDAO = new SubjectDAO();
    private final TimeSlotDAO timeSlotDAO = new TimeSlotDAO();
    private final TimetableDAO timetableDAO = new TimetableDAO();
    private final TeacherDAO teacherDAO = new TeacherDAO();
    private List<TimeSlot> cachedTimeSlots; // Cache time slots in memory
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("hh:mm a");

    public TimetableGenerator() {
        cachedTimeSlots = new ArrayList<>();
    }

    public List<String> generateTimetable(Batch batch) throws SQLException {
        List<String> warnings = new ArrayList<>();

        // Clear existing timetable and time slots for this batch
        timetableDAO.clearTimetableForBatch(batch.getBatchId());
        timeSlotDAO.clearTimeSlotsForBatch(batch.getBatchId());
        cachedTimeSlots = cachedTimeSlots.stream()
                .filter(ts -> ts.getBatchId() != batch.getBatchId())
                .collect(Collectors.toList());

        // Generate time slots for the batch with breaks managed by building
        generateBatchTimeSlots(batch);
        System.out.println("Generated " + cachedTimeSlots.size() + " time slots for batch " + batch.getName());

        List<Subject> subjects = subjectDAO.getSubjectsByBatchId(batch.getBatchId());
        System.out.println("Batch " + batch.getName() + " has " + subjects.size() + " subjects: " + 
                           subjects.stream().map(Subject::getName).toList());

        // Filter time slots for this batch, excluding breaks
        List<TimeSlot> schedulableSlots = cachedTimeSlots.stream()
                .filter(ts -> ts.getBatchId() == batch.getBatchId() && !ts.isBreak())
                .collect(Collectors.toList());

        // Use the batch's assigned building
        String assignedBuilding = batch.getBuildingName();
        List<Room> batchRooms = roomDAO.getAllRooms().stream()
                .filter(room -> room.getBuildingName().equals(assignedBuilding))
                .collect(Collectors.toList());
        if (batchRooms.isEmpty()) {
            warnings.add("No rooms available in building " + assignedBuilding + " for batch " + batch.getName());
            return warnings;
        }
        System.out.println("Assigned " + batch.getName() + " to " + assignedBuilding);

        List<Subject> daySubjects = new ArrayList<>(subjects);
        Collections.shuffle(daySubjects);

        int subjectsScheduled = 0;
        List<Subject> unschedulableSubjects = new ArrayList<>();
        Map<String, List<Batch>> buildingBatches = getBuildingBatches();
        Map<String, List<TimeSlot>> buildingBreaks = new HashMap<>();

        for (Subject subject : daySubjects) {
            boolean scheduled = false;
            int teacherId = subjectDAO.getTeacherIdForSubject(subject.getSubjectId());
            if (teacherId == -1) {
                warnings.add("Teacher not found for subject " + subject.getName());
                unschedulableSubjects.add(subject);
                continue;
            }

            for (TimeSlot timeSlot : schedulableSlots) {
                int timeSlotId = timeSlot.getTimeSlotId();
                if (timetableDAO.isBatchScheduled(batch.getBatchId(), timeSlotId)) {
                    continue;
                }

                if (isTeacherClashing(teacherId, timeSlotId, warnings)) {
                    continue;
                }

                // Check break constraints for the building
                if (isBreakTimeSlot(timeSlot, buildingBreaks, buildingBatches, batch, warnings)) {
                    continue;
                }

                for (Room room : batchRooms) {
                    if (subject.isLab() && !room.isLab()) {
                        System.out.println("Skipping " + room.getName() + " for " + subject.getName() + " (lab mismatch)");
                        continue;
                    }
                    if (!subject.isLab() && room.isLab()) {
                        System.out.println("Skipping " + room.getName() + " for " + subject.getName() + " (non-lab mismatch)");
                        continue;
                    }

                    if (!timetableDAO.isRoomScheduled(room.getRoomId(), timeSlotId)) {
                        int totalStudents = timetableDAO.getTotalStudentsInRoom(room.getRoomId(), timeSlotId);
                        if (totalStudents + batch.getNoOfStudents() <= room.getCapacity()) {
                            Timetable timetable = new Timetable(0, batch.getBatchId(), subject.getSubjectId(), room.getRoomId(), timeSlotId);
                            timetableDAO.addTimetable(timetable);
                            System.out.println("Scheduled " + subject.getName() + " for " + batch.getName() + " at " + 
                                               timeSlot.getStartTime().format(TIME_FORMATTER) + " in " + room.getName());
                            scheduled = true;
                            subjectsScheduled++;
                            break;
                        } else {
                            System.out.println("Room " + room.getName() + " at " + timeSlotId + " has insufficient capacity for " + batch.getName());
                        }
                    }
                }
                if (scheduled) break;
            }
            if (!scheduled) {
                unschedulableSubjects.add(subject);
                warnings.add("Could not schedule " + subject.getName() + " for " + batch.getName() + 
                             " due to teacher unavailability or room constraints");
            }
        }

        if (!unschedulableSubjects.isEmpty()) {
            StringBuilder warning = new StringBuilder("The following subjects for batch " + batch.getName() + 
                                                      " could not be scheduled:");
            for (Subject subject : unschedulableSubjects) {
                int teacherId = subjectDAO.getTeacherIdForSubject(subject.getSubjectId());
                Teacher teacher = teacherDAO.getTeacherById(teacherId);
                String teacherName = teacher != null ? teacher.getName() : "Teacher ID " + teacherId;
                warning.append("\n- ").append(subject.getName()).append(" (Teacher: ").append(teacherName).append(")");
            }
            warnings.add(warning.toString());
        }

        System.out.println("Scheduled " + subjectsScheduled + "/" + daySubjects.size() + " subjects for " + batch.getName());
        return warnings;
    }

    // Generate time slots for a specific batch with back-to-back classes and breaks after 2 periods
    private void generateBatchTimeSlots(Batch batch) throws SQLException {
        LocalTime startTime = batch.getStartTime();
        LocalTime endTime = batch.getEndTime();
        Duration slotDuration = Duration.ofMinutes(45);
        Duration breakDuration = Duration.ofMinutes(30);

        // Calculate total duration and number of possible slots
        long totalMinutes = Duration.between(startTime, endTime).toMinutes();
        long totalSlots = totalMinutes / 45; // Number of 45-minute slots

        if (totalSlots < 3) {
            System.out.println("Batch " + batch.getName() + " schedule too short for a break. Needs at least 3 slots (2 classes + 1 break).");
            return;
        }

        LocalTime currentTime = startTime;
        int periodsSinceLastBreak = 0;

        while (currentTime.isBefore(endTime)) {
            LocalTime nextTime = currentTime.plus(slotDuration);
            if (nextTime.isAfter(endTime)) nextTime = endTime;

            TimeSlot timeSlot = new TimeSlot(0, currentTime, nextTime, false, batch.getBatchId());
            timeSlotDAO.addTimeSlot(timeSlot);
            cachedTimeSlots.add(timeSlot);
            System.out.println("Generated time slot for " + batch.getName() + ": " + currentTime.format(TIME_FORMATTER) + " - " + nextTime.format(TIME_FORMATTER));

            currentTime = nextTime;
            periodsSinceLastBreak++;

            // Insert a break after 2 periods if time allows
            if (periodsSinceLastBreak == 2 && currentTime.plus(breakDuration).isBefore(endTime)) {
                LocalTime breakEndTime = currentTime.plus(breakDuration);
                if (breakEndTime.isAfter(endTime)) breakEndTime = endTime;

                TimeSlot breakSlot = new TimeSlot(0, currentTime, breakEndTime, true, batch.getBatchId());
                timeSlotDAO.addTimeSlot(breakSlot);
                cachedTimeSlots.add(breakSlot);
                System.out.println("Generated break slot for " + batch.getName() + ": " + currentTime.format(TIME_FORMATTER) + " - " + breakEndTime.format(TIME_FORMATTER) + " (Break)");

                currentTime = breakEndTime;
                periodsSinceLastBreak = 0;
            }
        }
    }

    // Enhanced teacher clash detection with warnings
    private boolean isTeacherClashing(int teacherId, int timeSlotId, List<String> warnings) throws SQLException {
        List<Timetable> existingSchedules = timetableDAO.getTimetableByTeacher(teacherId);
        TimeSlot currentSlot = cachedTimeSlots.stream()
                .filter(ts -> ts.getTimeSlotId() == timeSlotId)
                .findFirst()
                .orElseGet(() -> {
                    try {
                        return timeSlotDAO.getTimeSlotById(timeSlotId);
                    } catch (SQLException e) {
                        e.printStackTrace();
                        return null;
                    }
                });

        if (currentSlot == null) return true;

        for (Timetable schedule : existingSchedules) {
            TimeSlot scheduledSlot = cachedTimeSlots.stream()
                    .filter(ts -> ts.getTimeSlotId() == schedule.getTimeSlotId())
                    .findFirst()
                    .orElseGet(() -> {
                        try {
                            return timeSlotDAO.getTimeSlotById(schedule.getTimeSlotId());
                        } catch (SQLException e) {
                            e.printStackTrace();
                            return currentSlot;
                        }
                    });
            if (scheduledSlot != null && currentSlot.getStartTime().isBefore(scheduledSlot.getEndTime()) &&
                currentSlot.getEndTime().isAfter(scheduledSlot.getStartTime())) {
                // Log a warning about the teacher clash
                Teacher teacher = teacherDAO.getTeacherById(teacherId);
                String teacherName = teacher != null ? teacher.getName() : "Teacher ID " + teacherId;
                warnings.add("Teacher " + teacherName + " has a clash at " + 
                             currentSlot.getStartTime().format(TIME_FORMATTER) + " - " + 
                             currentSlot.getEndTime().format(TIME_FORMATTER));
                return true;
            }
        }
        return false;
    }

    // Helper method to get all batches grouped by building
    private Map<String, List<Batch>> getBuildingBatches() throws SQLException {
        List<Batch> allBatches = batchDAO.getAllBatches();
        Map<String, List<Batch>> buildingBatches = new HashMap<>();
        for (Batch batch : allBatches) {
            buildingBatches.computeIfAbsent(batch.getBuildingName(), k -> new ArrayList<>()).add(batch);
        }
        return buildingBatches;
    }

    // Check if the time slot is a break and enforce break limits
    private boolean isBreakTimeSlot(TimeSlot timeSlot, Map<String, List<TimeSlot>> buildingBreaks, 
                                   Map<String, List<Batch>> buildingBatches, Batch currentBatch, List<String> warnings) throws SQLException {
        if (!timeSlot.isBreak()) return false;

        String building = currentBatch.getBuildingName();
        List<TimeSlot> currentBreaks = buildingBreaks.computeIfAbsent(building, k -> new ArrayList<>());
        List<Batch> batchesInBuilding = buildingBatches.getOrDefault(building, new ArrayList<>());

        // Calculate total students for batches currently on break
        int totalStudentsOnBreak = 0;
        for (TimeSlot breakSlot : currentBreaks) {
            for (Batch batch : batchesInBuilding) {
                if (timetableDAO.isBatchScheduled(batch.getBatchId(), breakSlot.getTimeSlotId())) {
                    totalStudentsOnBreak += batch.getNoOfStudents();
                }
            }
        }

        // Add current batch's students if it would be on break
        totalStudentsOnBreak += currentBatch.getNoOfStudents();

        // Enforce break limits
        int maxBatchesOnBreak = (totalStudentsOnBreak > 50) ? 2 : 3;
        if (currentBreaks.size() >= maxBatchesOnBreak) {
            warnings.add("Break at " + timeSlot.getStartTime().format(TIME_FORMATTER) + " - " + 
                         timeSlot.getEndTime().format(TIME_FORMATTER) + " skipped for " + currentBatch.getName() + 
                         " in " + building + " due to max " + maxBatchesOnBreak + " batches on break (student limit exceeded).");
            return true;
        }

        currentBreaks.add(timeSlot);
        return false;
    }

    public void displayTimetable(String batchName) throws SQLException {
        BatchDAO batchDAO = new BatchDAO();
        Batch batch = batchDAO.getBatchByName(batchName);
        if (batch == null) {
            System.out.println("Batch not found.");
            return;
        }

        List<Timetable> timetable = timetableDAO.getTimetableByBatch(batchName);
        List<TimeSlot> allTimeSlots = cachedTimeSlots.stream()
                .filter(ts -> ts.getBatchId() == batch.getBatchId())
                .collect(Collectors.toList());

        String assignedBuilding = batch.getBuildingName();

        System.out.println("\n" + batchName + " Standard Timetable in " + assignedBuilding);
        System.out.println("Timing\t\tSubject\t\t\tTeacher\t\tRoom");
        System.out.println("---------------------------------------------------");

        for (TimeSlot timeSlot : allTimeSlots) {
            boolean slotScheduled = false;
            for (Timetable entry : timetable) {
                if (entry.getTimeSlotId() == timeSlot.getTimeSlotId()) {
                    String subjectQuery = "SELECT s.*, t.Name AS TeacherName FROM Subject s JOIN Teacher t ON s.TeacherId = t.TeacherId WHERE s.SubjectId = ?";
                    String roomQuery = "SELECT * FROM Room WHERE RoomId = ?";
                    String subjectName = null, teacherName = null, roomName = null;

                    try (Connection conn = db.DBConnection.getConnection()) {
                        try (PreparedStatement stmt = conn.prepareStatement(subjectQuery)) {
                            stmt.setInt(1, entry.getSubjectId());
                            try (ResultSet rs = stmt.executeQuery()) {
                                if (rs.next()) {
                                    subjectName = rs.getString("Name");
                                    teacherName = rs.getString("TeacherName");
                                }
                            }
                        }
                        try (PreparedStatement stmt = conn.prepareStatement(roomQuery)) {
                            stmt.setInt(1, entry.getRoomId());
                            try (ResultSet rs = stmt.executeQuery()) {
                                if (rs.next()) {
                                    roomName = rs.getString("Name");
                                }
                            }
                        }
                    }

                    if (subjectName != null && teacherName != null && roomName != null) {
                        System.out.printf("%s-%s\t%-20s\t%-10s\t%s%n",
                            timeSlot.getStartTime().format(TIME_FORMATTER),
                            timeSlot.getEndTime().format(TIME_FORMATTER),
                            subjectName,
                            teacherName,
                            roomName
                        );
                        slotScheduled = true;
                    }
                    break;
                }
            }
            if (!slotScheduled && timeSlot.isBreak()) {
                System.out.printf("%s-%s\t%-20s\t%-10s\t%s%n",
                    timeSlot.getStartTime().format(TIME_FORMATTER),
                    timeSlot.getEndTime().format(TIME_FORMATTER),
                    "Break Time",
                    "-",
                    "-"
                );
            } else if (!slotScheduled) {
                System.out.printf("%s-%s\t%-20s\t%-10s\t%s%n",
                    timeSlot.getStartTime().format(TIME_FORMATTER),
                    timeSlot.getEndTime().format(TIME_FORMATTER),
                    "",
                    "",
                    ""
                );
            }
        }
    }

    public List<Timetable> getTimetable(String batchName) throws SQLException {
        return timetableDAO.getTimetableByBatch(batchName);
    }

    public TimetableDAO getTimetableDAO() {
        return timetableDAO;
    }

    public TimeSlotDAO getTimeSlotDAO() {
        return timeSlotDAO;
    }

    public TeacherDAO getTeacherDAO() {
        return teacherDAO;
    }
}