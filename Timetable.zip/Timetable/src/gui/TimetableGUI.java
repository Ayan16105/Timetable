package gui;

import dao.BatchDAO;
import dao.SubjectDAO;
import dao.TeacherDAO;
import model.Batch;
import model.Subject;
import model.Teacher;
import model.Timetable;
import model.TimeSlot;
import service.TimetableGenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.print.*;
import java.text.MessageFormat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TimetableGUI extends JFrame {
    // Main components
    private final TimetableGenerator generator;
    private JComboBox<String> batchComboBox;
    private JTable timetableTable;
    private JTextArea logArea;
    
    // Batch management components
    private JTextField batchNameField;
    private JTextField batchStudentsField;
    private JComboBox<String> batchStartTimeComboBox;
    private JComboBox<String> batchEndTimeComboBox;
    private JComboBox<String> batchBuildingComboBox;
    private JTable batchTable;
    
    // Subject management components
    private JTextField subjectNameField;
    private JCheckBox subjectIsLabCheckBox;
    private JComboBox<String> subjectTeacherComboBox;
    private JTable subjectTable;
    private JComboBox<String> subjectBatchComboBox;
    
    // Teacher management components
    private JTextField teacherNameField;
    private JTable teacherTable;
    
    // Static variables
    private static final String[] BUILDINGS = {"First building", "Second building"};
    
    // UI Colors and Fonts
    private static final Color PRIMARY_COLOR = new Color(66, 139, 202);
    private static final Color SECONDARY_COLOR = new Color(240, 240, 240);
    private static final Color ACCENT_COLOR = new Color(92, 184, 92);
    private static final Color WARNING_COLOR = new Color(240, 173, 78);
    private static final Color DANGER_COLOR = new Color(217, 83, 79);
    private static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 16);
    private static final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 12);

    public TimetableGUI() {
        generator = new TimetableGenerator();
        initializeUI();
        setupLookAndFeel();
    }

    private void setupLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            logArea.append("Could not set system look and feel: " + e.getMessage() + "\n");
        }
    }

    private void initializeUI() {
        setTitle("SmartTimetable - By AYAN KHAN");
        setSize(1100, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        try {
            URL iconURL = getClass().getResource("timetable_icon.png");
            if (iconURL != null) {
                setIconImage(new ImageIcon(iconURL).getImage());
            }
        } catch (Exception e) {
            logArea.append("Icon image not found: " + e.getMessage() + "\n");
        }

        JTabbedPane mainTabbedPane = new JTabbedPane();
        mainTabbedPane.setFont(HEADER_FONT);
        mainTabbedPane.setBackground(Color.WHITE);
        mainTabbedPane.setForeground(PRIMARY_COLOR);

        createDashboardPanel(mainTabbedPane);
        createTimetablePanel(mainTabbedPane);
        createBatchManagementPanel(mainTabbedPane);
        createSubjectPanel(mainTabbedPane);
        createTeacherPanel(mainTabbedPane);

        getContentPane().setBackground(Color.WHITE);
        getContentPane().add(mainTabbedPane);

        loadBatches();
        loadBatches(subjectBatchComboBox);
    }
    
    private JTable createStyledTable(String[] columns) {
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex < columns.length && "Is Lab".equals(columns[columnIndex])) {
                    return Boolean.class;
                }
                return String.class;
            }
        };
        
        JTable table = new JTable(model);
        table.setFont(LABEL_FONT);
        table.setRowHeight(30);
        table.setShowGrid(true);
        table.setGridColor(new Color(230, 230, 230));
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setSelectionForeground(Color.BLACK);
        table.setFillsViewportHeight(true);
        
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                          boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                label.setBackground(new Color(42, 100, 150));
                label.setForeground(Color.WHITE);
                label.setFont(new Font("Segoe UI", Font.BOLD, 15));
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 1, Color.WHITE),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)
                ));
                return label;
            }
        };

        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
        
        TableColumnModel columnModel = table.getColumnModel();
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            int width = 100;
            if (i == 0) width = 150;
            else if (i == 1 && (columns[i].equals("Subject") || columns[i].equals("Name"))) width = 150;
            columnModel.getColumn(i).setMinWidth(width);
            columnModel.getColumn(i).setPreferredWidth(width);
        }
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        for (int i = 0; i < table.getColumnCount(); i++) {
            if (!columns[i].equals("Is Lab")) {
                table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
        
        return table;
    }
    
    private void createDashboardPanel(JTabbedPane mainTabbedPane) {
        JPanel dashboardPanel = new JPanel(new BorderLayout(15, 15));
        dashboardPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        dashboardPanel.setBackground(Color.WHITE);

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel titleLabel = new JLabel("SmartTimetable Dashboard");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(PRIMARY_COLOR);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        JPanel quickActionsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        quickActionsPanel.setBackground(Color.WHITE);
        
        JButton generateAllButton = createStyledButton("Generate All Timetables", ACCENT_COLOR);
        generateAllButton.addActionListener(e -> generateAllTimetables());
        
        JButton exportButton = createStyledButton("Export All Timetables", PRIMARY_COLOR);
        exportButton.addActionListener(e -> exportAllTimetables());
        
        JButton settingsButton = createStyledButton("Settings", Color.LIGHT_GRAY);
        settingsButton.addActionListener(e -> showSettings());
        
        quickActionsPanel.add(generateAllButton);
        quickActionsPanel.add(exportButton);
        quickActionsPanel.add(settingsButton);
        
        JPanel statsPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        statsPanel.setBackground(Color.WHITE);
        
        statsPanel.add(createStatPanel("Total Batches", countBatches(), PRIMARY_COLOR));
        statsPanel.add(createStatPanel("Total Subjects", countSubjects(), ACCENT_COLOR));
        statsPanel.add(createStatPanel("Total Teachers", countTeachers(), WARNING_COLOR));

        JPanel contentPanel = new JPanel(new BorderLayout(0, 20));
        contentPanel.setBackground(Color.WHITE);
        contentPanel.add(quickActionsPanel, BorderLayout.NORTH);
        contentPanel.add(statsPanel, BorderLayout.CENTER);
        
        dashboardPanel.add(headerPanel, BorderLayout.NORTH);
        dashboardPanel.add(contentPanel, BorderLayout.CENTER);
        
        mainTabbedPane.insertTab("Dashboard", null, dashboardPanel, "System Overview", 0);
        mainTabbedPane.setSelectedIndex(0);
    }

    private JPanel createStatPanel(String title, int value, Color color) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 1),
            new EmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel valueLabel = new JLabel(String.valueOf(value));
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        valueLabel.setForeground(color);
        
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        
        return panel;
    }

    private int countBatches() {
        try {
            BatchDAO batchDAO = new BatchDAO();
            return batchDAO.getAllBatches().size();
        } catch (SQLException e) {
            logArea.append("Error counting batches: " + e.getMessage() + "\n");
            return 0;
        }
    }

    private int countSubjects() {
        try {
            SubjectDAO subjectDAO = new SubjectDAO();
            return subjectDAO.getAllSubjects().size();
        } catch (SQLException e) {
            logArea.append("Error counting subjects: " + e.getMessage() + "\n");
            return 0;
        }
    }

    private int countTeachers() {
        try {
            TeacherDAO teacherDAO = new TeacherDAO();
            return teacherDAO.getAllTeachers().size();
        } catch (SQLException e) {
            logArea.append("Error counting teachers: " + e.getMessage() + "\n");
            return 0;
        }
    }

    private void exportAllTimetables() {
        try {
            BatchDAO batchDAO = new BatchDAO();
            List<Batch> batches = batchDAO.getAllBatches();
            if (batches.isEmpty()) {
                showErrorMessage("No batches available to export.");
                return;
            }

            boolean hasData = false;
            for (Batch batch : batches) {
                List<Timetable> timetable = generator.getTimetableDAO().getTimetableByBatch(batch.getName());
                if (!timetable.isEmpty()) {
                    hasData = true;
                    break;
                }
            }
            if (!hasData) {
                showErrorMessage("No timetable data available to export. Please generate timetables first.");
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Export All Timetables");
            fileChooser.setSelectedFile(new File("all_timetables_" + java.time.LocalDate.now() + ".csv"));
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));

            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                    DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

                    for (Batch batch : batches) {
                        String batchName = batch.getName();
                        List<Timetable> timetable = generator.getTimetableDAO().getTimetableByBatch(batchName);
                        List<TimeSlot> allTimeSlots = generator.getTimeSlotDAO().getAllTimeSlots();

                        writer.write("Batch: " + batchName + "\n");
                        writer.write("Start Time: " + batch.getStartTime().format(timeFormatter) + "\n");
                        writer.write("End Time: " + batch.getEndTime().format(timeFormatter) + "\n");
                        writer.write("Building: " + batch.getBuildingName() + "\n");
                        writer.write("Time,Subject,Teacher,Room\n");

                        if (timetable.isEmpty()) {
                            writer.write("No timetable data available for this batch.\n");
                            writer.write("\n");
                            continue;
                        }

                        LocalTime breakStart = batch.getBreakTime();
                        LocalTime breakEnd = breakStart != null ? breakStart.plusMinutes(30) : null;
                        boolean breakDisplayed = false;

                        for (TimeSlot timeSlot : allTimeSlots) {
                            if (breakStart != null && timeSlot.getStartTime().equals(breakStart) && !breakDisplayed) {
                                writer.write(String.format("%s - %s,Break Time,-,-\n",
                                    breakStart.format(timeFormatter),
                                    breakEnd.format(timeFormatter)));
                                breakDisplayed = true;
                                continue;
                            }

                            for (Timetable entry : timetable) {
                                if (entry.getTimeSlotId() == timeSlot.getTimeSlotId()) {
                                    String subjectQuery = "SELECT s.*, t.Name AS TeacherName FROM Subject s JOIN Teacher t ON s.TeacherId = t.TeacherId WHERE s.SubjectId = ?";
                                    String roomQuery = "SELECT * FROM Room WHERE RoomId = ?";
                                    String subjectName = null, teacherName = null, roomName = null;

                                    try (Connection conn = db.DBConnection.getConnection()) {
                                        try (PreparedStatement stmt = conn.prepareStatement(subjectQuery)) {
                                            stmt.setInt(1, entry.getSubjectId());
                                            try (ResultSet rs = stmt.executeQuery()) {
                                                if (rs.next()) {
                                                    subjectName = rs.getString("Name");
                                                    teacherName = rs.getString("TeacherName");
                                                }
                                            }
                                        }
                                        try (PreparedStatement stmt = conn.prepareStatement(roomQuery)) {
                                            stmt.setInt(1, entry.getRoomId());
                                            try (ResultSet rs = stmt.executeQuery()) {
                                                if (rs.next()) {
                                                    roomName = rs.getString("Name");
                                                }
                                            }
                                        }
                                    }

                                    if (subjectName != null && teacherName != null && roomName != null) {
                                        subjectName = subjectName.replace(",", ";");
                                        teacherName = teacherName.replace(",", ";");
                                        roomName = roomName.replace(",", ";");

                                        writer.write(String.format("%s - %s,%s,%s,%s\n",
                                            timeSlot.getStartTime().format(timeFormatter),
                                            timeSlot.getEndTime().format(timeFormatter),
                                            subjectName, teacherName, roomName));
                                    }
                                    break;
                                }
                            }
                        }
                        writer.write("\n");
                    }

                    logArea.append("✓ All timetables exported successfully to: " + fileToSave.getAbsolutePath() + "\n");
                    JOptionPane.showMessageDialog(
                        this,
                        "All timetables exported successfully to:\n" + fileToSave.getAbsolutePath(),
                        "Export Success",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                } catch (IOException e) {
                    logArea.append("Error exporting timetables: Failed to write to file - " + e.getMessage() + "\n");
                    showErrorMessage("Failed to export timetables: " + e.getMessage());
                } catch (SQLException e) {
                    logArea.append("Error exporting timetables: Database error - " + e.getMessage() + "\n");
                    showErrorMessage("Failed to export timetables: " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            logArea.append("Error accessing batch data: " + e.getMessage() + "\n");
            showErrorMessage("Failed to access batch data: " + e.getMessage());
        }
    }

    private void showSettings() {
        JDialog settingsDialog = new JDialog(this, "Settings", true);
        settingsDialog.setSize(400, 300);
        settingsDialog.setLocationRelativeTo(this);
        
        JPanel settingsPanel = new JPanel(new BorderLayout(10, 10));
        settingsPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        settingsPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Application Settings");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(PRIMARY_COLOR);
        
        JPanel contentPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        contentPanel.setBackground(Color.WHITE);
        
        contentPanel.add(new JLabel("DB Connection:"));
        JTextField dbConnectionField = new JTextField("jdbc:mysql://localhost:3306/timetable");
        contentPanel.add(dbConnectionField);
        
        contentPanel.add(new JLabel("Session Timeout (min):"));
        JTextField sessionTimeoutField = new JTextField("30");
        contentPanel.add(sessionTimeoutField);
        
        contentPanel.add(new JLabel("Theme:"));
        JComboBox<String> themeCombo = new JComboBox<>(new String[]{"Light", "Dark", "System"});
        contentPanel.add(themeCombo);
        
        JButton saveButton = createStyledButton("Save Settings", ACCENT_COLOR);
        saveButton.addActionListener(e -> {
            String dbConnection = dbConnectionField.getText();
            String timeout = sessionTimeoutField.getText();
            String theme = (String) themeCombo.getSelectedItem();
            
            try {
                int timeoutValue = Integer.parseInt(timeout);
                if (timeoutValue <= 0) {
                    showErrorMessage("Session timeout must be a positive number");
                    return;
                }
                
                logArea.append("Settings saved:\n");
                logArea.append("DB Connection: " + dbConnection + "\n");
                logArea.append("Session Timeout: " + timeout + " minutes\n");
                logArea.append("Theme: " + theme + "\n");
                
                JOptionPane.showMessageDialog(
                    settingsDialog,
                    "Settings saved successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
                );
                settingsDialog.dispose();
            } catch (NumberFormatException ex) {
                showErrorMessage("Invalid session timeout value");
            }
        });
        
        settingsPanel.add(titleLabel, BorderLayout.NORTH);
        settingsPanel.add(contentPanel, BorderLayout.CENTER);
        settingsPanel.add(saveButton, BorderLayout.SOUTH);
        
        settingsDialog.add(settingsPanel);
        settingsDialog.setVisible(true);
    }

    private void createTimetablePanel(JTabbedPane mainTabbedPane) {
        JPanel timetablePanel = new JPanel(new BorderLayout(15, 15));
        timetablePanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        timetablePanel.setBackground(Color.WHITE);
    
        JPanel controlPanel = new JPanel(new BorderLayout(10, 0));
        controlPanel.setBackground(Color.WHITE);
        
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        inputPanel.setBackground(Color.WHITE);
        
        JLabel batchLabel = new JLabel("Batch:");
        batchLabel.setFont(LABEL_FONT);
        inputPanel.add(batchLabel);
        
        batchComboBox = new JComboBox<>();
        batchComboBox.setFont(LABEL_FONT);
        batchComboBox.setPreferredSize(new Dimension(200, 30));
        inputPanel.add(batchComboBox);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton generateButton = createStyledButton("Generate", ACCENT_COLOR);
        generateButton.addActionListener(e -> generateTimetable());
        
        JButton displayButton = createStyledButton("Display", PRIMARY_COLOR);
        displayButton.addActionListener(e -> displayTimetable());
        
        JButton printButton = createStyledButton("Print", Color.DARK_GRAY);
        printButton.addActionListener(e -> printTimetable());
        
        buttonPanel.add(generateButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(printButton);
        
        controlPanel.add(inputPanel, BorderLayout.WEST);
        controlPanel.add(buttonPanel, BorderLayout.EAST);
        
        timetablePanel.add(controlPanel, BorderLayout.NORTH);
        
        timetableTable = createStyledTable(new String[]{"Time", "Subject", "Teacher", "Room"});
        JScrollPane tableScrollPane = new JScrollPane(timetableTable);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(SECONDARY_COLOR));
        tableScrollPane.getViewport().setBackground(Color.WHITE);
        
        timetablePanel.add(tableScrollPane, BorderLayout.CENTER);
    
        logArea = new JTextArea(5, 20);
        logArea.setEditable(false);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setBackground(new Color(245, 245, 245));
        logArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JScrollPane logScrollPane = new JScrollPane(logArea);
        logScrollPane.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(SECONDARY_COLOR),
            "System Log",
            1,
            0,
            new Font("Segoe UI", Font.BOLD, 12),
            PRIMARY_COLOR
        ));
        
        timetablePanel.add(logScrollPane, BorderLayout.SOUTH);
    
        mainTabbedPane.addTab("Timetable", null, timetablePanel, "View and generate timetables");
    
        loadBatches();
        if (batchComboBox.getItemCount() > 0) {
            batchComboBox.setSelectedIndex(0);
            displayTimetable();
        }
    }
    
    private String[] generateTimeOptions() {
        LocalTime start = LocalTime.of(8, 0);
        LocalTime end = LocalTime.of(18, 0);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        java.util.List<String> times = new java.util.ArrayList<>();
        LocalTime time = start;
        while (!time.isAfter(end)) {
            times.add(time.format(formatter));
            time = time.plusMinutes(15);
        }
        return times.toArray(new String[0]);
    }
    
    private void createBatchManagementPanel(JTabbedPane mainTabbedPane) {
        JPanel batchPanel = new JPanel(new BorderLayout(15, 15));
        batchPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        batchPanel.setBackground(Color.WHITE);
    
        JPanel formPanel = new JPanel(new BorderLayout(0, 15));
        formPanel.setBackground(Color.WHITE);
        
        JLabel formTitle = new JLabel("Batch Information");
        formTitle.setFont(HEADER_FONT);
        formTitle.setForeground(PRIMARY_COLOR);
        formPanel.add(formTitle, BorderLayout.NORTH);
        
        JPanel fieldsPanel = new JPanel(new GridLayout(5, 2, 15, 10));
        fieldsPanel.setBackground(Color.WHITE);
        
        JLabel nameLabel = new JLabel("Batch Name:");
        nameLabel.setFont(LABEL_FONT);
        fieldsPanel.add(nameLabel);
        
        batchNameField = createStyledTextField();
        fieldsPanel.add(batchNameField);
        
        JLabel studentsLabel = new JLabel("Number of Students:");
        studentsLabel.setFont(LABEL_FONT);
        fieldsPanel.add(studentsLabel);
        
        batchStudentsField = createStyledTextField();
        fieldsPanel.add(batchStudentsField);
        
        JLabel startTimeLabel = new JLabel("Start Time:");
        startTimeLabel.setFont(LABEL_FONT);
        fieldsPanel.add(startTimeLabel);
        
        String[] timeOptions = generateTimeOptions();
        batchStartTimeComboBox = new JComboBox<>(timeOptions);
        batchStartTimeComboBox.setFont(LABEL_FONT);
        batchStartTimeComboBox.setSelectedItem("09:15");
        fieldsPanel.add(batchStartTimeComboBox);
        
        JLabel endTimeLabel = new JLabel("End Time:");
        endTimeLabel.setFont(LABEL_FONT);
        fieldsPanel.add(endTimeLabel);
        
        batchEndTimeComboBox = new JComboBox<>(timeOptions);
        batchEndTimeComboBox.setFont(LABEL_FONT);
        batchEndTimeComboBox.setSelectedItem("14:30");
        fieldsPanel.add(batchEndTimeComboBox);
        
        JLabel buildingLabel = new JLabel("Building:");
        buildingLabel.setFont(LABEL_FONT);
        fieldsPanel.add(buildingLabel);
        
        batchBuildingComboBox = new JComboBox<>(BUILDINGS);
        batchBuildingComboBox.setFont(LABEL_FONT);
        fieldsPanel.add(batchBuildingComboBox);
        
        formPanel.add(fieldsPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton addBatchButton = createStyledButton("Add Batch", ACCENT_COLOR);
        addBatchButton.addActionListener(e -> addBatch());
        
        JButton updateBatchButton = createStyledButton("Update", PRIMARY_COLOR);
        updateBatchButton.addActionListener(e -> updateBatch());
        
        JButton clearButton = createStyledButton("Clear Fields", Color.LIGHT_GRAY);
        clearButton.addActionListener(e -> clearBatchFields());
        
        buttonPanel.add(addBatchButton);
        buttonPanel.add(updateBatchButton);
        buttonPanel.add(clearButton);
        
        formPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        batchTable = createStyledTable(new String[]{"ID", "Name", "Students", "Start Time", "End Time", "Building"});
        loadBatchTable();
        
        batchTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = batchTable.getSelectedRow();
                if (row >= 0) {
                    batchNameField.setText((String) batchTable.getValueAt(row, 1));
                    batchStudentsField.setText(batchTable.getValueAt(row, 2).toString());
                    batchStartTimeComboBox.setSelectedItem(batchTable.getValueAt(row, 3).toString());
                    batchEndTimeComboBox.setSelectedItem(batchTable.getValueAt(row, 4).toString());
                    batchBuildingComboBox.setSelectedItem(batchTable.getValueAt(row, 5));
                }
            }
        });
        
        JScrollPane tableScrollPane = new JScrollPane(batchTable);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(SECONDARY_COLOR));
        tableScrollPane.getViewport().setBackground(Color.WHITE);
        
        JPanel deletePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        deletePanel.setBackground(Color.WHITE);
        
        JButton deleteBatchButton = createStyledButton("Delete Selected Batch", DANGER_COLOR);
        deleteBatchButton.addActionListener(e -> deleteBatch());
        deletePanel.add(deleteBatchButton);
        
        JPanel centerPanel = new JPanel(new BorderLayout(0, 15));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.add(tableScrollPane, BorderLayout.CENTER);
        centerPanel.add(deletePanel, BorderLayout.SOUTH);
        
        batchPanel.add(formPanel, BorderLayout.NORTH);
        batchPanel.add(centerPanel, BorderLayout.CENTER);
    
        mainTabbedPane.addTab("Manage Batches", null, batchPanel, "Add, edit, or delete batches");
    }

    private void createSubjectPanel(JTabbedPane mainTabbedPane) {
        JPanel subjectPanel = new JPanel(new BorderLayout(15, 15));
        subjectPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        subjectPanel.setBackground(Color.WHITE);

        JPanel formPanel = new JPanel(new BorderLayout(0, 15));
        formPanel.setBackground(Color.WHITE);
        
        JLabel formTitle = new JLabel("Subject Information");
        formTitle.setFont(HEADER_FONT);
        formTitle.setForeground(PRIMARY_COLOR);
        formPanel.add(formTitle, BorderLayout.NORTH);
        
        JPanel fieldsPanel = new JPanel(new GridLayout(4, 2, 15, 10));
        fieldsPanel.setBackground(Color.WHITE);
        
        JLabel batchLabel = new JLabel("Select Batch:");
        batchLabel.setFont(LABEL_FONT);
        fieldsPanel.add(batchLabel);
        
        subjectBatchComboBox = new JComboBox<>();
        subjectBatchComboBox.setFont(LABEL_FONT);
        subjectBatchComboBox.addActionListener(e -> loadSubjects(subjectBatchComboBox));
        fieldsPanel.add(subjectBatchComboBox);
        
        JLabel nameLabel = new JLabel("Subject Name:");
        nameLabel.setFont(LABEL_FONT);
        fieldsPanel.add(nameLabel);
        
        subjectNameField = createStyledTextField();
        fieldsPanel.add(subjectNameField);
        
        JLabel isLabLabel = new JLabel("Is Lab:");
        isLabLabel.setFont(LABEL_FONT);
        fieldsPanel.add(isLabLabel);
        
        subjectIsLabCheckBox = new JCheckBox();
        subjectIsLabCheckBox.setBackground(Color.WHITE);
        fieldsPanel.add(subjectIsLabCheckBox);
        
        JLabel teacherLabel = new JLabel("Teacher:");
        teacherLabel.setFont(LABEL_FONT);
        fieldsPanel.add(teacherLabel);
        
        subjectTeacherComboBox = new JComboBox<>();
        subjectTeacherComboBox.setFont(LABEL_FONT);
        loadTeachers(subjectTeacherComboBox);
        fieldsPanel.add(subjectTeacherComboBox);
        
        formPanel.add(fieldsPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton addSubjectButton = createStyledButton("Add Subject", ACCENT_COLOR);
        addSubjectButton.addActionListener(e -> addSubject(subjectBatchComboBox));
        
        JButton updateSubjectButton = createStyledButton("Update", PRIMARY_COLOR);
        updateSubjectButton.addActionListener(e -> updateSubject(subjectBatchComboBox));
        
        JButton clearButton = createStyledButton("Clear Fields", Color.LIGHT_GRAY);
        clearButton.addActionListener(e -> clearSubjectFields());
        
        buttonPanel.add(addSubjectButton);
        buttonPanel.add(updateSubjectButton);
        buttonPanel.add(clearButton);
        
        formPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        subjectTable = createStyledTable(new String[]{"ID", "Name", "Is Lab", "Teacher"});
        
        subjectTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = subjectTable.getSelectedRow();
                if (row >= 0) {
                    subjectNameField.setText((String) subjectTable.getValueAt(row, 1));
                    subjectIsLabCheckBox.setSelected((Boolean) subjectTable.getValueAt(row, 2));
                    subjectTeacherComboBox.setSelectedItem(subjectTable.getValueAt(row, 3));
                }
            }
        });
        
        JScrollPane tableScrollPane = new JScrollPane(subjectTable);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(SECONDARY_COLOR));
        tableScrollPane.getViewport().setBackground(Color.WHITE);
        
        JPanel deletePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        deletePanel.setBackground(Color.WHITE);
        
        JButton deleteSubjectButton = createStyledButton("Delete Selected Subject", DANGER_COLOR);
        deleteSubjectButton.addActionListener(e -> deleteSubject(subjectBatchComboBox));
        deletePanel.add(deleteSubjectButton);
        
        JPanel centerPanel = new JPanel(new BorderLayout(0, 15));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.add(tableScrollPane, BorderLayout.CENTER);
        centerPanel.add(deletePanel, BorderLayout.SOUTH);
        
        subjectPanel.add(formPanel, BorderLayout.NORTH);
        subjectPanel.add(centerPanel, BorderLayout.CENTER);

        mainTabbedPane.addTab("Manage Subjects", null, subjectPanel, "Add, edit, or delete subjects");
    }

    private void createTeacherPanel(JTabbedPane mainTabbedPane) {
        JPanel teacherPanel = new JPanel(new BorderLayout(15, 15));
        teacherPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        teacherPanel.setBackground(Color.WHITE);

        JPanel formPanel = new JPanel(new BorderLayout(0, 15));
        formPanel.setBackground(Color.WHITE);
        
        JLabel formTitle = new JLabel("Teacher Information");
        formTitle.setFont(HEADER_FONT);
        formTitle.setForeground(PRIMARY_COLOR);
        formPanel.add(formTitle, BorderLayout.NORTH);
        
        JPanel fieldsPanel = new JPanel(new GridLayout(1, 2, 15, 10));
        fieldsPanel.setBackground(Color.WHITE);
        
        JLabel nameLabel = new JLabel("Teacher Name:");
        nameLabel.setFont(LABEL_FONT);
        fieldsPanel.add(nameLabel);
        
        teacherNameField = createStyledTextField();
        fieldsPanel.add(teacherNameField);
        
        formPanel.add(fieldsPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton addTeacherButton = createStyledButton("Add Teacher", ACCENT_COLOR);
        addTeacherButton.addActionListener(e -> addTeacher());

        JButton updateTeacherButton = createStyledButton("Update", PRIMARY_COLOR);
        updateTeacherButton.addActionListener(e -> updateTeacher());
        
        JButton clearButton = createStyledButton("Clear Fields", Color.LIGHT_GRAY);
        clearButton.addActionListener(e -> clearTeacherFields());
        
        buttonPanel.add(addTeacherButton);
        buttonPanel.add(updateTeacherButton);
        buttonPanel.add(clearButton);
        
        formPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        teacherTable = createStyledTable(new String[]{"ID", "Name"});
        loadTeacherTable();
        
        teacherTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = teacherTable.getSelectedRow();
                if (row >= 0) {
                    teacherNameField.setText((String) teacherTable.getValueAt(row, 1));
                }
            }
        });
        
        JScrollPane tableScrollPane = new JScrollPane(teacherTable);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(SECONDARY_COLOR));
        tableScrollPane.getViewport().setBackground(Color.WHITE);
        
        JPanel deletePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        deletePanel.setBackground(Color.WHITE);
        
        JButton deleteTeacherButton = createStyledButton("Delete Selected Teacher", DANGER_COLOR);
        deleteTeacherButton.addActionListener(e -> deleteTeacher());
        deletePanel.add(deleteTeacherButton);
        
        JPanel centerPanel = new JPanel(new BorderLayout(0, 15));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.add(tableScrollPane, BorderLayout.CENTER);
        centerPanel.add(deletePanel, BorderLayout.SOUTH);
        
        teacherPanel.add(formPanel, BorderLayout.NORTH);
        teacherPanel.add(centerPanel, BorderLayout.CENTER);

        mainTabbedPane.addTab("Manage Teachers", null, teacherPanel, "Add, edit, or delete teachers");
    }

    private JTextField createStyledTextField() {
        JTextField textField = new JTextField();
        textField.setFont(LABEL_FONT);
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(SECONDARY_COLOR),
            BorderFactory.createEmptyBorder(5, 7, 5, 7)
        ));
        return textField;
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(BUTTON_FONT);
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(140, 32));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(darken(color, 0.1f));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }

    private Color darken(Color color, float fraction) {
        int red = Math.max(0, Math.round(color.getRed() * (1 - fraction)));
        int green = Math.max(0, Math.round(color.getGreen() * (1 - fraction)));
        int blue = Math.max(0, Math.round(color.getBlue() * (1 - fraction)));
        return new Color(red, green, blue);
    }

    private void clearBatchFields() {
        batchNameField.setText("");
        batchStudentsField.setText("");
        batchStartTimeComboBox.setSelectedItem("09:15");
        batchEndTimeComboBox.setSelectedItem("14:30");
        batchBuildingComboBox.setSelectedIndex(0);
    }
    
    private void clearSubjectFields() {
        subjectNameField.setText("");
        subjectIsLabCheckBox.setSelected(false);
        subjectTeacherComboBox.setSelectedIndex(0);
    }
    
    private void clearTeacherFields() {
        teacherNameField.setText("");
    }

    private void loadBatchTable() {
        try {
            BatchDAO batchDAO = new BatchDAO();
            List<Batch> batches = batchDAO.getAllBatches();
            
            DefaultTableModel model = (DefaultTableModel) batchTable.getModel();
            model.setRowCount(0);
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            
            for (Batch batch : batches) {
                model.addRow(new Object[]{
                    batch.getBatchId(),
                    batch.getName(),
                    batch.getNoOfStudents(),
                    batch.getStartTime().format(formatter),
                    batch.getEndTime().format(formatter),
                    batch.getBuildingName()
                });
            }
        } catch (SQLException e) {
            logArea.append("Error loading batches: " + e.getMessage() + "\n");
        }
    }
    
    private void loadTeacherTable() {
        try {
            TeacherDAO teacherDAO = new TeacherDAO();
            List<Teacher> teachers = teacherDAO.getAllTeachers();
            
            DefaultTableModel model = (DefaultTableModel) teacherTable.getModel();
            model.setRowCount(0);
            
            for (Teacher teacher : teachers) {
                model.addRow(new Object[]{
                    teacher.getTeacherId(),
                    teacher.getName()
                });
            }
        } catch (SQLException e) {
            logArea.append("Error loading teachers: " + e.getMessage() + "\n");
        }
    }
    
    private void loadBatches() {
        loadBatches(batchComboBox);
    }
    
    private void loadBatches(JComboBox<String> comboBox) {
        try {
            BatchDAO batchDAO = new BatchDAO();
            List<String> batches = batchDAO.getAllBatches().stream()
                    .map(Batch::getName)
                    .collect(Collectors.toList());
            comboBox.removeAllItems();
            for (String batch : batches) {
                comboBox.addItem(batch);
            }
            
            if (batchTable != null) {
                loadBatchTable();
            }
        } catch (SQLException e) {
            logArea.append("Error loading batches: " + e.getMessage() + "\n");
        }
    }
    
    private void loadTeachers(JComboBox<String> comboBox) {
        try {
            TeacherDAO teacherDAO = new TeacherDAO();
            List<Teacher> teachers = teacherDAO.getAllTeachers();
            comboBox.removeAllItems();
            for (Teacher teacher : teachers) {
                comboBox.addItem(teacher.getName());
            }
        } catch (SQLException e) {
            logArea.append("Error loading teachers: " + e.getMessage() + "\n");
        }
    }
    
    private void loadSubjects(JComboBox<String> batchComboBox) {
        try {
            String batchName = (String) batchComboBox.getSelectedItem();
            if (batchName == null) return;
            
            BatchDAO batchDAO = new BatchDAO();
            SubjectDAO subjectDAO = new SubjectDAO();
            TeacherDAO teacherDAO = new TeacherDAO();
            Batch batch = batchDAO.getBatchByName(batchName);
            if (batch == null) return;
    
            List<Subject> subjects = subjectDAO.getSubjectsByBatchId(batch.getBatchId());
            DefaultTableModel model = (DefaultTableModel) subjectTable.getModel();
            model.setRowCount(0);
            
            Map<Integer, Integer> teacherAssignmentCount = new HashMap<>();
    
            for (Subject subject : subjects) {
                int teacherId = subject.getTeacherId();
                Teacher teacher = teacherDAO.getTeacherById(teacherId);
                String teacherName = teacher != null ? teacher.getName() : "Unknown";
                
                model.addRow(new Object[]{
                    subject.getSubjectId(),
                    subject.getName(),
                    subject.isLab(),
                    teacherName
                });
    
                teacherAssignmentCount.put(teacherId, teacherAssignmentCount.getOrDefault(teacherId, 0) + 1);
            }
    
            checkTeacherDistribution(teacherAssignmentCount);
        } catch (SQLException e) {
            logArea.append("Error loading subjects: " + e.getMessage() + "\n");
        }
    }
    
    private void checkTeacherDistribution(Map<Integer, Integer> teacherAssignmentCount) throws SQLException {
        TeacherDAO teacherDAO = new TeacherDAO();
        int totalSubjects = 0;
        for (int count : teacherAssignmentCount.values()) {
            totalSubjects += count;
        }
        if (teacherAssignmentCount.isEmpty()) return;
    
        int avgSubjectsPerTeacher = totalSubjects / teacherAssignmentCount.size();
        for (Map.Entry<Integer, Integer> entry : teacherAssignmentCount.entrySet()) {
            int teacherId = entry.getKey();
            int count = entry.getValue();
            if (count > avgSubjectsPerTeacher + 2) {
                Teacher teacher = teacherDAO.getTeacherById(teacherId);
                String teacherName = teacher != null ? teacher.getName() : "Unknown";
                logArea.append("Warning: Teacher " + teacherName + " is assigned to " + count + 
                              " subjects, which is significantly above average (" + avgSubjectsPerTeacher + 
                              "). Consider reassigning.\n");
            }
        }
    }
    
    private void addBatch() {
        try {
            String name = batchNameField.getText().trim();
            if (name.isEmpty()) {
                showErrorMessage("Batch name cannot be empty");
                return;
            }
            
            BatchDAO batchDAO = new BatchDAO();
            Batch existingBatch = batchDAO.getBatchByName(name);
            if (existingBatch != null) {
                showErrorMessage("A batch with the name '" + name + "' already exists");
                return;
            }
            
            int noOfStudents;
            try {
                noOfStudents = Integer.parseInt(batchStudentsField.getText().trim());
                if (noOfStudents <= 0) {
                    showErrorMessage("Number of students must be greater than zero");
                    return;
                }
            } catch (NumberFormatException e) {
                showErrorMessage("Invalid number of students");
                return;
            }
            
            LocalTime startTime = LocalTime.parse((String) batchStartTimeComboBox.getSelectedItem());
            LocalTime endTime = LocalTime.parse((String) batchEndTimeComboBox.getSelectedItem());
            
            if (!startTime.isBefore(endTime)) {
                showErrorMessage("Start time must be before end time");
                return;
            }
            
            String buildingName = (String) batchBuildingComboBox.getSelectedItem();
    
            Batch newBatch = new Batch(0, name, noOfStudents, startTime, endTime, null, buildingName);
            batchDAO.addBatch(newBatch);
            
            logArea.append("✓ Batch " + name + " added successfully.\n");
            loadBatches();
            loadBatches(subjectBatchComboBox);
            clearBatchFields();
        } catch (Exception e) {
            logArea.append("Error adding batch: " + e.getMessage() + "\n");
            showErrorMessage("Failed to add batch: " + e.getMessage());
        }
    }
    
    private void updateBatch() {
        try {
            int selectedRow = batchTable.getSelectedRow();
            if (selectedRow == -1) {
                showErrorMessage("Please select a batch to update");
                return;
            }
            
            int batchId = (int) batchTable.getValueAt(selectedRow, 0);
            String originalName = (String) batchTable.getValueAt(selectedRow, 1);
            
            String name = batchNameField.getText().trim();
            if (name.isEmpty()) {
                showErrorMessage("Batch name cannot be empty");
                return;
            }
            
            BatchDAO batchDAO = new BatchDAO();
            if (!name.equals(originalName)) {
                Batch existingBatch = batchDAO.getBatchByName(name);
                if (existingBatch != null) {
                    showErrorMessage("A batch with the name '" + name + "' already exists");
                    return;
                }
            }
            
            int noOfStudents;
            try {
                noOfStudents = Integer.parseInt(batchStudentsField.getText().trim());
                if (noOfStudents <= 0) {
                    showErrorMessage("Number of students must be greater than zero");
                    return;
                }
            } catch (NumberFormatException e) {
                showErrorMessage("Invalid number of students");
                return;
            }
            
            LocalTime startTime = LocalTime.parse((String) batchStartTimeComboBox.getSelectedItem());
            LocalTime endTime = LocalTime.parse((String) batchEndTimeComboBox.getSelectedItem());
            
            if (!startTime.isBefore(endTime)) {
                showErrorMessage("Start time must be before end time");
                return;
            }
            
            String buildingName = (String) batchBuildingComboBox.getSelectedItem();
    
            Batch batch = new Batch(batchId, name, noOfStudents, startTime, endTime, null, buildingName);
            batchDAO.updateBatch(batch);
            
            logArea.append("✓ Batch " + name + " updated successfully.\n");
            loadBatches();
            loadBatches(subjectBatchComboBox);
            clearBatchFields();
        } catch (Exception e) {
            logArea.append("Error updating batch: " + e.getMessage() + "\n");
            showErrorMessage("Failed to update batch: " + e.getMessage());
        }
    }
    
    private void deleteBatch() {
        try {
            int selectedRow = batchTable.getSelectedRow();
            if (selectedRow == -1) {
                showErrorMessage("Please select a batch to delete");
                return;
            }
            
            int batchId = (int) batchTable.getValueAt(selectedRow, 0);
            String batchName = (String) batchTable.getValueAt(selectedRow, 1);
            
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete batch '" + batchName + "'?\n" +
                "This will also delete all subjects associated with this batch.",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                BatchDAO batchDAO = new BatchDAO();
                batchDAO.deleteBatch(batchId);
                
                logArea.append("✓ Batch '" + batchName + "' deleted successfully.\n");
                loadBatches();
                loadBatches(subjectBatchComboBox);
                clearBatchFields();
            }
        } catch (SQLException e) {
            logArea.append("Error deleting batch: " + e.getMessage() + "\n");
            showErrorMessage("Failed to delete batch: " + e.getMessage());
        }
    }
    
    private void addSubject(JComboBox<String> batchComboBox) {
        try {
            String batchName = (String) batchComboBox.getSelectedItem();
            if (batchName == null || batchName.isEmpty()) {
                showErrorMessage("Please select a batch");
                return;
            }
            
            String subjectName = subjectNameField.getText().trim();
            if (subjectName.isEmpty()) {
                showErrorMessage("Subject name cannot be empty");
                return;
            }
            
            BatchDAO batchDAO = new BatchDAO();
            Batch batch = batchDAO.getBatchByName(batchName);
            if (batch == null) {
                showErrorMessage("Selected batch not found");
                return;
            }
            
            SubjectDAO subjectDAO = new SubjectDAO();
            List<Subject> subjects = subjectDAO.getSubjectsByBatchId(batch.getBatchId());
            if (subjects.stream().anyMatch(s -> s.getName().equalsIgnoreCase(subjectName))) {
                showErrorMessage("A subject with the name '" + subjectName + "' already exists in this batch");
                return;
            }
            
            boolean isLab = subjectIsLabCheckBox.isSelected();
            String teacherName = (String) subjectTeacherComboBox.getSelectedItem();
            if (teacherName == null || teacherName.isEmpty()) {
                showErrorMessage("Please select a teacher");
                return;
            }
    
            TeacherDAO teacherDAO = new TeacherDAO();
            Teacher teacher = teacherDAO.getTeacherByName(teacherName);
            if (teacher == null) {
                showErrorMessage("Selected teacher not found");
                return;
            }
    
            Subject newSubject = new Subject(0, batch.getBatchId(), teacher.getTeacherId(), subjectName, isLab);
            subjectDAO.addSubject(newSubject);
            
            logArea.append("✓ Subject '" + subjectName + "' added to batch '" + batchName + 
                          "' with teacher '" + teacherName + "'.\n");
            loadSubjects(batchComboBox);
            clearSubjectFields();
        } catch (SQLException e) {
            logArea.append("Error adding subject: " + e.getMessage() + "\n");
            showErrorMessage("Failed to add subject: " + e.getMessage());
        }
    }
    
    private void updateSubject(JComboBox<String> batchComboBox) {
        try {
            int selectedRow = subjectTable.getSelectedRow();
            if (selectedRow == -1) {
                showErrorMessage("Please select a subject to update");
                return;
            }
            
            int subjectId = (int) subjectTable.getValueAt(selectedRow, 0);
            String originalName = (String) subjectTable.getValueAt(selectedRow, 1);
            
            String subjectName = subjectNameField.getText().trim();
            if (subjectName.isEmpty()) {
                showErrorMessage("Subject name cannot be empty");
                return;
            }
            
            String batchName = (String) batchComboBox.getSelectedItem();
            if (batchName == null || batchName.isEmpty()) {
                showErrorMessage("Please select a batch");
                return;
            }
            
            BatchDAO batchDAO = new BatchDAO();
            Batch batch = batchDAO.getBatchByName(batchName);
            if (batch == null) {
                showErrorMessage("Selected batch not found");
                return;
            }
            
            SubjectDAO subjectDAO = new SubjectDAO();
            if (!subjectName.equalsIgnoreCase(originalName)) {
                List<Subject> subjects = subjectDAO.getSubjectsByBatchId(batch.getBatchId());
                if (subjects.stream().anyMatch(s -> s.getName().equalsIgnoreCase(subjectName))) {
                    showErrorMessage("A subject with the name '" + subjectName + "' already exists in this batch");
                    return;
                }
            }
            
            boolean isLab = subjectIsLabCheckBox.isSelected();
            String teacherName = (String) subjectTeacherComboBox.getSelectedItem();
            if (teacherName == null || teacherName.isEmpty()) {
                showErrorMessage("Please select a teacher");
                return;
            }
    
            TeacherDAO teacherDAO = new TeacherDAO();
            Teacher teacher = teacherDAO.getTeacherByName(teacherName);
            if (teacher == null) {
                showErrorMessage("Selected teacher not found");
                return;
            }
    
            Subject subject = new Subject(subjectId, batch.getBatchId(), teacher.getTeacherId(), subjectName, isLab);
            subjectDAO.updateSubject(subject);
            
            logArea.append("✓ Subject '" + subjectName + "' updated with teacher '" + teacherName + "'.\n");
            loadSubjects(batchComboBox);
            clearSubjectFields();
        } catch (SQLException e) {
            logArea.append("Error updating subject: " + e.getMessage() + "\n");
            showErrorMessage("Failed to update subject: " + e.getMessage());
        }
    }
    
    private void deleteSubject(JComboBox<String> batchComboBox) {
        try {
            int selectedRow = subjectTable.getSelectedRow();
            if (selectedRow == -1) {
                showErrorMessage("Please select a subject to delete");
                return;
            }
            
            int subjectId = (int) subjectTable.getValueAt(selectedRow, 0);
            String subjectName = (String) subjectTable.getValueAt(selectedRow, 1);
            
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete subject '" + subjectName + "'?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                SubjectDAO subjectDAO = new SubjectDAO();
                subjectDAO.deleteSubject(subjectId);
                
                logArea.append("✓ Subject '" + subjectName + "' deleted successfully.\n");
                loadSubjects(batchComboBox);
                clearSubjectFields();
            }
        } catch (SQLException e) {
            logArea.append("Error deleting subject: " + e.getMessage() + "\n");
            showErrorMessage("Failed to delete subject: " + e.getMessage());
        }
    }
    
    private void addTeacher() {
        try {
            String name = teacherNameField.getText().trim();
            if (name.isEmpty()) {
                showErrorMessage("Teacher name cannot be empty");
                return;
            }
            
            TeacherDAO teacherDAO = new TeacherDAO();
            Teacher existingTeacher = teacherDAO.getTeacherByName(name);
            if (existingTeacher != null) {
                showErrorMessage("A teacher with the name '" + name + "' already exists");
                return;
            }
            
            String insertQuery = "INSERT INTO Teacher (Name) VALUES (?)";
            try (Connection conn = db.DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                stmt.setString(1, name);
                stmt.executeUpdate();
                
                logArea.append("✓ Teacher '" + name + "' added successfully.\n");
                loadTeachers(subjectTeacherComboBox);
                loadTeacherTable();
                clearTeacherFields();
            }
        } catch (SQLException e) {
            logArea.append("Error adding teacher: " + e.getMessage() + "\n");
            showErrorMessage("Failed to add teacher: " + e.getMessage());
        }
    }
    
    private void updateTeacher() {
        try {
            int selectedRow = teacherTable.getSelectedRow();
            if (selectedRow == -1) {
                showErrorMessage("Please select a teacher to update");
                return;
            }

            int teacherId = (int) teacherTable.getValueAt(selectedRow, 0);
            String originalName = (String) teacherTable.getValueAt(selectedRow, 1);

            String name = teacherNameField.getText().trim();
            if (name.isEmpty()) {
                showErrorMessage("Teacher name cannot be empty");
                return;
            }

            TeacherDAO teacherDAO = new TeacherDAO();
            if (!name.equalsIgnoreCase(originalName)) {
                Teacher existingTeacher = teacherDAO.getTeacherByName(name);
                if (existingTeacher != null) {
                    showErrorMessage("A teacher with the name '" + name + "' already exists");
                    return;
                }
            }

            Teacher teacher = new Teacher(teacherId, name);
            teacherDAO.updateTeacher(teacher);

            logArea.append("✓ Teacher '" + originalName + "' updated to '" + name + "' successfully.\n");
            loadTeachers(subjectTeacherComboBox);
            loadTeacherTable();
            clearTeacherFields();
        } catch (SQLException e) {
            logArea.append("Error updating teacher: " + e.getMessage() + "\n");
            showErrorMessage("Failed to update teacher: " + e.getMessage());
        }
    }
    
    private void deleteTeacher() {
        try {
            int selectedRow = teacherTable.getSelectedRow();
            if (selectedRow == -1) {
                showErrorMessage("Please select a teacher to delete");
                return;
            }
            
            int teacherId = (int) teacherTable.getValueAt(selectedRow, 0);
            String teacherName = (String) teacherTable.getValueAt(selectedRow, 1);
            
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete teacher '" + teacherName + "'?\n" +
                "This will affect all subjects assigned to this teacher.",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                TeacherDAO teacherDAO = new TeacherDAO();
                teacherDAO.deleteTeacher(teacherId);
                
                logArea.append("✓ Teacher '" + teacherName + "' deleted successfully.\n");
                loadTeachers(subjectTeacherComboBox);
                loadTeacherTable();
                clearTeacherFields();
            }
        } catch (SQLException e) {
            logArea.append("Error deleting teacher: " + e.getMessage() + "\n");
            showErrorMessage("Failed to delete teacher: " + e.getMessage());
        }
    }
    
    private void generateAllTimetables() {
        try {
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "This will generate timetables for all batches. Continue?",
                "Generate All Timetables",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                JDialog progressDialog = new JDialog(this, "Generating All Timetables", true);
                progressDialog.setSize(300, 100);
                progressDialog.setLocationRelativeTo(this);
                
                JPanel progressPanel = new JPanel(new BorderLayout(10, 10));
                progressPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
                progressPanel.setBackground(Color.WHITE);
                
                JLabel progressLabel = new JLabel("Processing... Please wait");
                progressLabel.setFont(LABEL_FONT);
                JProgressBar progressBar = new JProgressBar();
                progressBar.setIndeterminate(true);
                
                progressPanel.add(progressLabel, BorderLayout.NORTH);
                progressPanel.add(progressBar, BorderLayout.CENTER);
                progressDialog.add(progressPanel);
                
                new Thread(() -> {
                    try {
                        BatchDAO batchDAO = new BatchDAO();
                        List<Batch> batches = batchDAO.getAllBatches();
                        for (Batch batch : batches) {
                            List<String> warnings = generator.generateTimetable(batch);
                            SwingUtilities.invokeLater(() -> {
                                logArea.append("✓ Timetable generated for batch '" + batch.getName() + "'.\n");
                                for (String warning : warnings) {
                                    logArea.append("Warning: " + warning + "\n");
                                }
                            });
                        }
                        SwingUtilities.invokeLater(() -> {
                            progressDialog.dispose();
                            JOptionPane.showMessageDialog(
                                this,
                                "All timetables generated successfully!",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE
                            );
                        });
                    } catch (SQLException e) {
                        SwingUtilities.invokeLater(() -> {
                            progressDialog.dispose();
                            showErrorMessage("Failed to generate all timetables: " + e.getMessage());
                            logArea.append("Error generating all timetables: " + e.getMessage() + "\n");
                        });
                    }
                }).start();
                
                progressDialog.setVisible(true);
            }
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
            logArea.append("Error: " + e.getMessage() + "\n");
        }
    }
    
    private void generateTimetable() {
        String batchName = (String) batchComboBox.getSelectedItem();
        if (batchName == null || batchName.isEmpty()) {
            showErrorMessage("Please select a batch to generate the timetable");
            return;
        }

        try {
            BatchDAO batchDAO = new BatchDAO();
            Batch batch = batchDAO.getBatchByName(batchName);
            if (batch == null) {
                showErrorMessage("Batch not found");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(
                this,
                "This will generate the timetable for batch " + batchName + ". Continue?",
                "Generate Timetable",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );

            if (confirm == JOptionPane.YES_OPTION) {
                JDialog progressDialog = new JDialog(this, "Generating Timetable", true);
                progressDialog.setSize(300, 100);
                progressDialog.setLocationRelativeTo(this);

                JPanel progressPanel = new JPanel(new BorderLayout(10, 10));
                progressPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
                progressPanel.setBackground(Color.WHITE);

                JLabel progressLabel = new JLabel("Processing... Please wait");
                progressLabel.setFont(LABEL_FONT);
                JProgressBar progressBar = new JProgressBar();
                progressBar.setIndeterminate(true);

                progressPanel.add(progressLabel, BorderLayout.NORTH);
                progressPanel.add(progressBar, BorderLayout.CENTER);
                progressDialog.add(progressPanel);

                new Thread(() -> {
                    try {
                        List<String> warnings = generator.generateTimetable(batch);
                        SwingUtilities.invokeLater(() -> {
                            progressDialog.dispose();
                            JOptionPane.showMessageDialog(
                                this,
                                "Timetable generated successfully for batch " + batchName + "!",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE
                            );
                            logArea.append("✓ Timetable generated successfully for batch " + batchName + ".\n");
                            for (String warning : warnings) {
                                logArea.append("Warning: " + warning + "\n");
                            }
                            displayTimetable();
                        });
                    } catch (SQLException e) {
                        SwingUtilities.invokeLater(() -> {
                            progressDialog.dispose();
                            showErrorMessage("Failed to generate timetable: " + e.getMessage());
                            logArea.append("Error generating timetable: " + e.getMessage() + "\n");
                        });
                    }
                }).start();

                progressDialog.setVisible(true);
            }
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
            logArea.append("Error: " + e.getMessage() + "\n");
        }
    }
    
    private void displayTimetable() {
        String batchName = (String) batchComboBox.getSelectedItem();
        if (batchName == null || batchName.isEmpty()) {
            showErrorMessage("Please select a batch");
            return;
        }
    
        try {
            BatchDAO batchDAO = new BatchDAO();
            Batch batch = batchDAO.getBatchByName(batchName);
            if (batch == null) {
                showErrorMessage("Batch not found");
                return;
            }
    
            List<Timetable> timetable = generator.getTimetableDAO().getTimetableByBatch(batchName);
            if (timetable.isEmpty()) {
                showErrorMessage("No timetable data found for this batch. Please generate a timetable first.");
                return;
            }
            
            List<TimeSlot> allTimeSlots = generator.getTimeSlotDAO().getAllTimeSlots().stream()
                .filter(ts -> ts.getBatchId() == batch.getBatchId())
                .collect(Collectors.toList());
    
            DefaultTableModel model = (DefaultTableModel) timetableTable.getModel();
            model.setRowCount(0);
            
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    
            LocalTime lastTime = batch.getStartTime();
            for (TimeSlot timeSlot : allTimeSlots) {
                if (timeSlot.isBreak()) {
                    model.addRow(new Object[]{
                        timeSlot.getStartTime().format(timeFormatter) + " - " + timeSlot.getEndTime().format(timeFormatter),
                        "Break Time",
                        "-",
                        "-"
                    });
                    lastTime = timeSlot.getEndTime();
                    continue;
                }

                for (Timetable entry : timetable) {
                    if (entry.getTimeSlotId() == timeSlot.getTimeSlotId()) {
                        String subjectQuery = "SELECT s.*, t.Name AS TeacherName FROM Subject s JOIN Teacher t ON s.TeacherId = t.TeacherId WHERE s.SubjectId = ?";
                        String roomQuery = "SELECT * FROM Room WHERE RoomId = ?";
                        String subjectName = null, teacherName = null, roomName = null;
    
                        try (Connection conn = db.DBConnection.getConnection()) {
                            try (PreparedStatement stmt = conn.prepareStatement(subjectQuery)) {
                                stmt.setInt(1, entry.getSubjectId());
                                try (ResultSet rs = stmt.executeQuery()) {
                                    if (rs.next()) {
                                        subjectName = rs.getString("Name");
                                        teacherName = rs.getString("TeacherName");
                                    }
                                }
                            }
                            try (PreparedStatement stmt = conn.prepareStatement(roomQuery)) {
                                stmt.setInt(1, entry.getRoomId());
                                try (ResultSet rs = stmt.executeQuery()) {
                                    if (rs.next()) {
                                        roomName = rs.getString("Name");
                                    }
                                }
                            }
                        }
    
                        if (subjectName != null && teacherName != null && roomName != null) {
                            model.addRow(new Object[]{
                                timeSlot.getStartTime().format(timeFormatter) + " - " + timeSlot.getEndTime().format(timeFormatter),
                                subjectName,
                                teacherName,
                                roomName
                            });
                            lastTime = timeSlot.getEndTime();
                        }
                        break;
                    }
                }
            }
            
            logArea.append("✓ Timetable for batch '" + batchName + "' displayed successfully.\n");
        } catch (SQLException e) {
            logArea.append("Error displaying timetable: " + e.getMessage() + "\n");
            showErrorMessage("Failed to display timetable: " + e.getMessage());
        }
    }
    
    private void printTimetable() {
        if (timetableTable.getRowCount() == 0) {
            showErrorMessage("No timetable data to print. Please display a timetable first.");
            return;
        }
    
        try {
            String batchName = (String) batchComboBox.getSelectedItem();
            if (batchName == null) batchName = "Timetable";
    
            BatchDAO batchDAO = new BatchDAO();
            Batch batch = batchDAO.getBatchByName(batchName);
            String buildingName = (batch != null) ? batch.getBuildingName() : "Unknown Building";
    
            TableColumnModel columnModel = timetableTable.getColumnModel();
            int[] originalWidths = new int[columnModel.getColumnCount()];
            for (int i = 0; i < columnModel.getColumnCount(); i++) {
                originalWidths[i] = columnModel.getColumn(i).getWidth();
                columnModel.getColumn(i).setPreferredWidth(i == 0 ? 150 : 100);
            }
    
            MessageFormat header = new MessageFormat("Timetable for Batch: " + batchName + " | Building: " + buildingName);
            MessageFormat footer = new MessageFormat("Page {0} - Printed on " + java.time.LocalDate.now());
    
            PrinterJob printerJob = PrinterJob.getPrinterJob();
            printerJob.setPrintable(timetableTable.getPrintable(
                JTable.PrintMode.FIT_WIDTH,
                header,
                footer
            ));
    
            if (printerJob.printDialog()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Preparing to print the timetable for " + batchName + " (Building: " + buildingName + ").\nPlease confirm your printer settings.",
                    "Print Preview",
                    JOptionPane.INFORMATION_MESSAGE
                );
    
                printerJob.print();
                logArea.append("✓ Timetable printed successfully for batch '" + batchName + "' (Building: " + buildingName + ").\n");
                JOptionPane.showMessageDialog(
                    this,
                    "Timetable printed successfully!",
                    "Print Success",
                    JOptionPane.INFORMATION_MESSAGE
                );
            } else {
                logArea.append("Printing canceled by user.\n");
            }
    
            for (int i = 0; i < columnModel.getColumnCount(); i++) {
                columnModel.getColumn(i).setPreferredWidth(originalWidths[i]);
            }
        } catch (PrinterException e) {
            logArea.append("Error printing timetable: " + e.getMessage() + "\n");
            showErrorMessage("Failed to print timetable: " + e.getMessage());
        } catch (SQLException e) {
            logArea.append("Error fetching batch data for printing: " + e.getMessage() + "\n");
            showErrorMessage("Failed to fetch batch data for printing: " + e.getMessage());
        } catch (Exception e) {
            logArea.append("Unexpected error during printing: " + e.getMessage() + "\n");
            showErrorMessage("Unexpected error during printing: " + e.getMessage());
        }
    }
    
    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(
            this,
            message,
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            try {
                JWindow splash = new JWindow();
                JPanel splashContent = new JPanel(new BorderLayout());
                splashContent.setBorder(BorderFactory.createLineBorder(PRIMARY_COLOR, 2));
                
                JLabel titleLabel = new JLabel("TimetableAI", JLabel.CENTER);
                titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
                titleLabel.setForeground(PRIMARY_COLOR);
                
                JLabel subtitleLabel = new JLabel("Smart Scheduling System", JLabel.CENTER);
                subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
                
                JPanel textPanel = new JPanel(new BorderLayout());
                textPanel.setBackground(Color.WHITE);
                textPanel.add(titleLabel, BorderLayout.CENTER);
                textPanel.add(subtitleLabel, BorderLayout.SOUTH);
                
                JProgressBar progressBar = new JProgressBar();
                progressBar.setIndeterminate(true);
                progressBar.setForeground(PRIMARY_COLOR);
                
                splashContent.add(textPanel, BorderLayout.CENTER);
                splashContent.add(progressBar, BorderLayout.SOUTH);
                
                splash.setContentPane(splashContent);
                splash.setSize(400, 200);
                splash.setLocationRelativeTo(null);
                splash.setVisible(true);
                
                Timer timer = new Timer(2000, e -> {
                    splash.dispose();
                    new TimetableGUI().setVisible(true);
                });
                timer.setRepeats(false);
                timer.start();
            } catch (Exception e) {
                e.printStackTrace();
                new TimetableGUI().setVisible(true);
            }
        });
    }
}