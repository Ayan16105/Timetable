-- Create Database
CREATE DATABASE IF NOT EXISTS timetable;
USE timetable;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS Timetable;
DROP TABLE IF EXISTS TimeSlot;
DROP TABLE IF EXISTS Subject;
DROP TABLE IF EXISTS Room;
DROP TABLE IF EXISTS Batch;
DROP TABLE IF EXISTS Teacher;

-- Create Tables
CREATE TABLE Batch (
    BatchId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    NoOfStudents INT NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    BreakTime TIME NOT NULL,
    BuildingName VARCHAR(50) NOT NULL
);

CREATE TABLE Room (
    RoomId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    BuildingName VARCHAR(50) NOT NULL,
    IsLab BOOLEAN NOT NULL,
    Capacity INT NOT NULL
);

CREATE TABLE Teacher (
    TeacherId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL
);

CREATE TABLE Subject (
    SubjectId INT AUTO_INCREMENT PRIMARY KEY,
    BatchId INT NOT NULL,
    TeacherId INT NOT NULL,
    Name VARCHAR(50) NOT NULL,
    IsLab BOOLEAN NOT NULL,
    FOREIGN KEY (BatchId) REFERENCES Batch(BatchId),
    FOREIGN KEY (TeacherId) REFERENCES Teacher(TeacherId)
);

CREATE TABLE TimeSlot (
    TimeSlotId INT AUTO_INCREMENT PRIMARY KEY,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    IsBreak BOOLEAN NOT NULL
);

CREATE TABLE Timetable (
    TimetableId INT AUTO_INCREMENT PRIMARY KEY,
    BatchId INT NOT NULL,
    SubjectId INT NOT NULL,
    RoomId INT NOT NULL,
    TimeSlotId INT NOT NULL,
    FOREIGN KEY (BatchId) REFERENCES Batch(BatchId),
    FOREIGN KEY (SubjectId) REFERENCES Subject(SubjectId),
    FOREIGN KEY (RoomId) REFERENCES Room(RoomId),
    FOREIGN KEY (TimeSlotId) REFERENCES TimeSlot(TimeSlotId)
);

-- Insert Dummy Data
-- Batches (Staggered break times, with BuildingName)
INSERT INTO Batch (Name, NoOfStudents, StartTime, EndTime, BreakTime, BuildingName) VALUES
('BCA_Sem1_A', 30, '09:15:00', '14:30:00', '10:45:00', 'First building'),
('BCA_Sem1_B', 30, '09:15:00', '14:30:00', '10:45:00', 'First building'),
('BCA_Sem1_C', 30, '09:15:00', '14:30:00', '11:15:00', 'Second building'),
('BCA_Sem2_A', 25, '09:15:00', '14:30:00', '11:15:00', 'Second building'),
('BCA_Sem2_B', 25, '09:15:00', '14:30:00', '11:45:00', 'First building'),
('BCA_Sem2_C', 25, '09:15:00', '14:30:00', '11:45:00', 'First building');

-- Rooms (Two buildings: First building and Second building)
INSERT INTO Room (Name, BuildingName, IsLab, Capacity) VALUES
('PHP', 'Second building', FALSE, 40),
('SF', 'Second building', FALSE, 40),
('Android Lab', 'Second building', TRUE, 30),
('Java', 'Second building', FALSE, 40),
('Lab', 'Second building', TRUE, 30),
('Room 101', 'First building', FALSE, 40),
('Room 102', 'First building', FALSE, 40),
('Lab 1', 'First building', TRUE, 30),
('Room 103', 'First building', FALSE, 40),
('Lab 2', 'First building', TRUE, 30);

-- Teachers (Adding more teachers)
INSERT INTO Teacher (Name) VALUES
('V.sir/D.Mam'),  -- TeacherId 1
('D.sir'),       -- TeacherId 2
('R.sir'),       -- TeacherId 3
('S.mam'),       -- TeacherId 4
('V.sir'),       -- TeacherId 5
('A.mam'),       -- TeacherId 6
('B.sir'),       -- TeacherId 7
('C.mam'),       -- TeacherId 8
('D.mam'),       -- TeacherId 9
('E.sir');       -- TeacherId 10

-- Subjects (Assigning teachers to avoid overlap where possible)
INSERT INTO Subject (BatchId, TeacherId, Name, IsLab) VALUES
-- BCA_Sem1_A
(1, 1, 'Java Lab Remedial', TRUE),
(1, 2, 'Remedial Tally Lab/JS Lab', TRUE),
(1, 3, 'Java', FALSE),
(1, 4, 'CN', FALSE),
(1, 5, 'JS', FALSE),

-- BCA_Sem1_B
(2, 6, 'Java Lab Remedial', TRUE),
(2, 7, 'Remedial Tally Lab/JS Lab', TRUE),
(2, 8, 'Java', FALSE),
(2, 9, 'CN', FALSE),
(2, 10, 'JS', FALSE),

-- BCA_Sem1_C
(3, 1, 'Java Lab Remedial', TRUE),
(3, 2, 'Remedial Tally Lab/JS Lab', TRUE),
(3, 3, 'Java', FALSE),
(3, 4, 'CN', FALSE),
(3, 5, 'Java Script', FALSE),

-- BCA_Sem2_A
(4, 6, 'Visual Programming', FALSE),
(4, 7, 'Mobile App (Android Programming)/Android Lab', TRUE),
(4, 8, 'Java Project with JDBC', FALSE),
(4, 9, 'Java Project with JDBC Lab', TRUE),

-- BCA_Sem2_B
(5, 1, 'Visual Programming', FALSE),
(5, 2, 'Mobile App (Android Programming)/Android Lab', TRUE),
(5, 3, 'Java Project with JDBC', FALSE),
(5, 4, 'Java Project with JDBC Lab', TRUE),

-- BCA_Sem2_C
(6, 6, 'Visual Programming', FALSE),
(6, 7, 'Mobile App (Android Programming)/Android Lab', TRUE),
(6, 8, 'Java Project with JDBC', FALSE),
(6, 9, 'Java Project with JDBC Lab', TRUE);

-- Time Slots (Daily schedule with staggered breaks)
INSERT INTO TimeSlot (StartTime, EndTime, IsBreak) VALUES
('09:15:00', '10:00:00', FALSE),  -- Period 1
('10:00:00', '10:45:00', FALSE),  -- Period 2
('10:45:00', '11:15:00', TRUE),   -- Break 1 (for BCA_Sem1_A, BCA_Sem1_B)
('11:15:00', '11:45:00', TRUE),   -- Break 2 (for BCA_Sem1_C, BCA_Sem2_A)
('11:45:00', '12:15:00', TRUE),   -- Break 3 (for BCA_Sem2_B, BCA_Sem2_C)
('11:15:00', '12:00:00', FALSE),  -- Period 3 (for batches breaking at 10:45)
('12:00:00', '12:45:00', FALSE),  -- Period 4
('12:15:00', '13:00:00', FALSE),  -- Period 3 (for batches breaking at 11:15 or 11:45)
('13:00:00', '13:45:00', FALSE),  -- Period 5
('13:45:00', '14:30:00', FALSE);  -- Period 6